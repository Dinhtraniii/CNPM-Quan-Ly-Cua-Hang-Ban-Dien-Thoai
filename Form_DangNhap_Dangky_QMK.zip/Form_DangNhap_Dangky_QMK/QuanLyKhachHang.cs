﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class QuanLyKhachHang : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select * from KHACHHANG";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_KhachHang.DataSource = table;
        }
        public QuanLyKhachHang()
        {
            InitializeComponent();
        }

        private void dataGridView_KhachHang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_KhachHang.CurrentRow.Index;
            textBox_MaKH.Text = dataGridView_KhachHang.Rows[i].Cells[0].Value.ToString();
            textBox_HoTenKH.Text = dataGridView_KhachHang.Rows[i].Cells[1].Value.ToString();
            textbox_DiaChiKH.Text = dataGridView_KhachHang.Rows[i].Cells[2].Value.ToString();
            textbox_DienThoaiKH.Text = dataGridView_KhachHang.Rows[i].Cells[3].Value.ToString();
            textbox_TenDangNhap.Text = dataGridView_KhachHang.Rows[i].Cells[4].Value.ToString();
            textbox_MatKhau.Text = dataGridView_KhachHang.Rows[i].Cells[5].Value.ToString();
            dateTimePicker_NgaySinh.Text = dataGridView_KhachHang.Rows[i].Cells[6].Value.ToString();
            string gioiTinh = dataGridView_KhachHang.Rows[i].Cells[7].Value.ToString();
            if (gioiTinh == "True")
            {
                comboBox_GioiTinh.Text = "Nam";
            }
            else if (gioiTinh == "False")
            {
                comboBox_GioiTinh.Text = "Nữ";
            }
            textBox_Email.Text = dataGridView_KhachHang.Rows[i].Cells[8].Value.ToString();
        }
        private void LoadComboBox()
        {
            comboBox_GioiTinh.Items.Clear();
            List<PhanLoai> phanLoais = new List<PhanLoai>()
            {
                new PhanLoai() { Loai = "True", GioiTinh = "Nam" },
                new PhanLoai() { Loai = "False", GioiTinh = "Nữ" },
            };
            comboBox_GioiTinh.DataSource = phanLoais;
            comboBox_GioiTinh.DisplayMember = "GioiTinh";
            comboBox_GioiTinh.ValueMember = "Loai";
        }
        private void QuanLyKhachHang_Load(object sender, EventArgs e)
        {
            LoadComboBox();
            sqlConnection.Open();
            loaddata();
        }

        private void button_Them_Click(object sender, EventArgs e)
        {
            string gioitinh = comboBox_GioiTinh.SelectedValue.ToString();
            if (textBox_HoTenKH.Text == "" || textbox_DiaChiKH.Text == "" || textbox_DienThoaiKH.Text == "" || textbox_TenDangNhap.Text == "" || textbox_MatKhau.Text == "" || dateTimePicker_NgaySinh.Text == "" || comboBox_GioiTinh.Text == "" || textBox_Email.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "insert into KHACHHANG(HoTenKH, DiaChiKH, DienThoaiKH, TenDN, MatKhau, NgaySinh, GioiTinh, Email) values('" + textBox_HoTenKH.Text + "','" + textbox_DiaChiKH.Text + "','" + textbox_DienThoaiKH.Text + "','" + textbox_TenDangNhap.Text + "','" + textbox_MatKhau.Text + "','" + dateTimePicker_NgaySinh.Text + "','" + gioitinh + "','" + textBox_Email.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã thêm dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            string gioitinh = comboBox_GioiTinh.SelectedValue.ToString();
            if (textBox_HoTenKH.Text == "" || textbox_DiaChiKH.Text == "" || textbox_DienThoaiKH.Text == "" || textbox_TenDangNhap.Text == "" || textbox_MatKhau.Text == "" || dateTimePicker_NgaySinh.Text == "" || comboBox_GioiTinh.Text == "" || textBox_Email.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update KHACHHANG set HoTenKH = '" + textBox_HoTenKH.Text + "', DiaChiKH = '" + textbox_DiaChiKH.Text + "', DienThoaiKH= '" + textbox_DienThoaiKH.Text + "', TenDN = '" + textbox_TenDangNhap.Text + "', MatKhau = '" + textbox_MatKhau.Text + "', NgaySinh = '" + dateTimePicker_NgaySinh.Text + "', GioiTinh = '" + gioitinh + "', Email = '" + textBox_Email.Text + "'  where MaKH = '" + textBox_MaKH.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            if (textBox_HoTenKH.Text == "" || textbox_DiaChiKH.Text == "" || textbox_DienThoaiKH.Text == "" || textbox_TenDangNhap.Text == "" || textbox_MatKhau.Text == "" || dateTimePicker_NgaySinh.Text == "" || comboBox_GioiTinh.Text == "" || textBox_Email.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "delete from KHACHHANG where MaKH= '" + textBox_MaKH.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã xóa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textBox_MaKH.Clear();
            textBox_HoTenKH.Clear();
            textbox_DiaChiKH.Clear();
            textbox_DienThoaiKH.Clear();
            textBox_Email.Clear();
            textbox_MatKhau.Clear();
            textbox_TenDangNhap.Clear();
            comboBox_GioiTinh.ResetText();
            dateTimePicker_NgaySinh.ResetText();
        }
    }
}
