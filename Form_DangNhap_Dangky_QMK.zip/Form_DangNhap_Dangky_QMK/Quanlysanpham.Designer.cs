﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class Quanlysanpham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quanlysanpham));
            flowLayoutPanel8 = new FlowLayoutPanel();
            pictureBox3 = new PictureBox();
            label_ThongTinSanPham = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            pictureBox1 = new PictureBox();
            label_TinhTrangSanPham = new Label();
            flowLayoutPanel2 = new FlowLayoutPanel();
            pictureBox2 = new PictureBox();
            label_ThongSoKyThuat = new Label();
            flowLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // flowLayoutPanel8
            // 
            flowLayoutPanel8.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel8.Controls.Add(pictureBox3);
            flowLayoutPanel8.Controls.Add(label_ThongTinSanPham);
            flowLayoutPanel8.Location = new Point(245, 126);
            flowLayoutPanel8.Name = "flowLayoutPanel8";
            flowLayoutPanel8.Size = new Size(231, 63);
            flowLayoutPanel8.TabIndex = 4;
            flowLayoutPanel8.Click += flowLayoutPanel8_Click;
            flowLayoutPanel8.MouseEnter += pictureBox3_MouseEnter_1;
            flowLayoutPanel8.MouseLeave += pictureBox3_MouseLeave_1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(7, 7);
            pictureBox3.Margin = new Padding(7, 7, 3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(52, 50);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            pictureBox3.Click += flowLayoutPanel8_Click;
            pictureBox3.MouseEnter += pictureBox3_MouseEnter_1;
            pictureBox3.MouseLeave += pictureBox3_MouseLeave_1;
            // 
            // label_ThongTinSanPham
            // 
            label_ThongTinSanPham.Location = new Point(70, 22);
            label_ThongTinSanPham.Margin = new Padding(8, 22, 3, 0);
            label_ThongTinSanPham.Name = "label_ThongTinSanPham";
            label_ThongTinSanPham.Size = new Size(153, 18);
            label_ThongTinSanPham.TabIndex = 3;
            label_ThongTinSanPham.Text = "THÔNG TIN SẢN PHẨM";
            label_ThongTinSanPham.Click += flowLayoutPanel8_Click;
            label_ThongTinSanPham.MouseEnter += pictureBox3_MouseEnter_1;
            label_ThongTinSanPham.MouseLeave += pictureBox3_MouseLeave_1;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel1.Controls.Add(pictureBox1);
            flowLayoutPanel1.Controls.Add(label_TinhTrangSanPham);
            flowLayoutPanel1.Location = new Point(245, 210);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(231, 63);
            flowLayoutPanel1.TabIndex = 4;
            flowLayoutPanel1.Click += label_TinhTrangSanPham_Click_1;
            flowLayoutPanel1.MouseEnter += pictureBox1_MouseEnter_1;
            flowLayoutPanel1.MouseLeave += pictureBox1_MouseLeave_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(7, 7);
            pictureBox1.Margin = new Padding(7, 7, 3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(52, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += label_TinhTrangSanPham_Click_1;
            pictureBox1.MouseEnter += pictureBox1_MouseEnter_1;
            pictureBox1.MouseLeave += pictureBox1_MouseLeave_1;
            // 
            // label_TinhTrangSanPham
            // 
            label_TinhTrangSanPham.Location = new Point(70, 22);
            label_TinhTrangSanPham.Margin = new Padding(8, 22, 3, 0);
            label_TinhTrangSanPham.Name = "label_TinhTrangSanPham";
            label_TinhTrangSanPham.Size = new Size(153, 21);
            label_TinhTrangSanPham.TabIndex = 3;
            label_TinhTrangSanPham.Text = "TÌNH TRẠNG SẢN PHẨM";
            label_TinhTrangSanPham.Click += label_TinhTrangSanPham_Click_1;
            label_TinhTrangSanPham.MouseEnter += pictureBox1_MouseEnter_1;
            label_TinhTrangSanPham.MouseLeave += pictureBox1_MouseLeave_1;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel2.Controls.Add(pictureBox2);
            flowLayoutPanel2.Controls.Add(label_ThongSoKyThuat);
            flowLayoutPanel2.Location = new Point(245, 296);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(231, 63);
            flowLayoutPanel2.TabIndex = 5;
            flowLayoutPanel2.Click += label_ThongSoKyThuat_Click_1;
            flowLayoutPanel2.MouseEnter += label_ThongSoKyThuat_MouseEnter_1;
            flowLayoutPanel2.MouseLeave += label_ThongSoKyThuat_MouseLeave_1;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(7, 7);
            pictureBox2.Margin = new Padding(7, 7, 3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(52, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            pictureBox2.Click += label_ThongSoKyThuat_Click_1;
            pictureBox2.MouseEnter += label_ThongSoKyThuat_MouseEnter_1;
            pictureBox2.MouseLeave += label_ThongSoKyThuat_MouseLeave_1;
            // 
            // label_ThongSoKyThuat
            // 
            label_ThongSoKyThuat.Location = new Point(70, 22);
            label_ThongSoKyThuat.Margin = new Padding(8, 22, 3, 0);
            label_ThongSoKyThuat.Name = "label_ThongSoKyThuat";
            label_ThongSoKyThuat.Size = new Size(153, 19);
            label_ThongSoKyThuat.TabIndex = 3;
            label_ThongSoKyThuat.Text = "THÔNG SỐ KỸ THUẬT";
            label_ThongSoKyThuat.Click += label_ThongSoKyThuat_Click_1;
            label_ThongSoKyThuat.MouseEnter += label_ThongSoKyThuat_MouseEnter_1;
            label_ThongSoKyThuat.MouseLeave += label_ThongSoKyThuat_MouseLeave_1;
            // 
            // Quanlysanpham
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(730, 500);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(flowLayoutPanel8);
            Controls.Add(flowLayoutPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Quanlysanpham";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tra cứu giáo viên";
            Load += Quanlysanpham_Load;
            flowLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel flowLayoutPanel8;
        private PictureBox pictureBox3;
        private Label label_ThongTinSanPham;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox1;
        private Label label_TinhTrangSanPham;
        private FlowLayoutPanel flowLayoutPanel2;
        private PictureBox pictureBox2;
        private Label label_ThongSoKyThuat;
    }
}