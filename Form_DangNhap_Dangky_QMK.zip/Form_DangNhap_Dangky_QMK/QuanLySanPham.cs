﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class Quanlysanpham : Form
    {
        int x = 170, y = 202, a = 1;
        Font HoverFont = new Font("Segoe UI", 9, FontStyle.Bold);
        Font ResetFont = new Font("Segoe UI", 9, FontStyle.Regular);
        public Quanlysanpham()
        {
            InitializeComponent();
        }
        Modify modify = new Modify();

        private void pictureBox3_MouseEnter(object sender, EventArgs e)
        {
            label_ThongTinSanPham.Font = HoverFont;
            label_ThongTinSanPham.ForeColor = Color.Red;
        }
        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            label_ThongTinSanPham.Font = ResetFont;
            label_ThongTinSanPham.ForeColor = Color.Black;
        }

        private void label_ThongTinSanPham_MouseEnter(object sender, EventArgs e)
        {
            label_ThongTinSanPham.Font = HoverFont;
            label_ThongTinSanPham.ForeColor = Color.Red;
        }

        private void label_ThongTinSanPham_MouseLeave(object sender, EventArgs e)
        {
            label_ThongTinSanPham.Font = ResetFont;
            label_ThongTinSanPham.ForeColor = Color.Black;
        }

        private void pictureBox2_MouseEnter(object sender, EventArgs e)
        {
            label_ThongSoKyThuat.Font = HoverFont;
            label_ThongSoKyThuat.ForeColor = Color.Red;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            label_ThongSoKyThuat.Font = ResetFont;
            label_ThongSoKyThuat.ForeColor = Color.Black;
        }

        private void label_ThongSoKyThuat_MouseEnter(object sender, EventArgs e)
        {
            label_ThongSoKyThuat.Font = HoverFont;
            label_ThongSoKyThuat.ForeColor = Color.Red;
        }

        private void label_ThongSoKyThuat_MouseLeave(object sender, EventArgs e)
        {
            label_ThongSoKyThuat.Font = ResetFont;
            label_ThongSoKyThuat.ForeColor = Color.Black;
        }

        private void label_TinhTrangSanPham_MouseEnter(object sender, EventArgs e)
        {
            label_TinhTrangSanPham.Font = HoverFont;
            label_TinhTrangSanPham.ForeColor = Color.Red;
        }

        private void label_TinhTrangSanPham_MouseLeave(object sender, EventArgs e)
        {
            label_TinhTrangSanPham.Font = ResetFont;
            label_TinhTrangSanPham.ForeColor = Color.Black;
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            label_TinhTrangSanPham.Font = HoverFont;
            label_TinhTrangSanPham.ForeColor = Color.Red;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            label_TinhTrangSanPham.Font = ResetFont;
            label_TinhTrangSanPham.ForeColor = Color.Black;
        }

        private void Quanlysanpham_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel8_Click(object sender, EventArgs e)
        {
            ThongTinSanPham thongTinSanPham = new ThongTinSanPham();
            thongTinSanPham.Show();
        }

        private void label_TinhTrangSanPham_Click_1(object sender, EventArgs e)
        {
            TinhTrangSanPham tinhTrangSanPham = new TinhTrangSanPham();
            tinhTrangSanPham.Show();
        }

        private void label_ThongSoKyThuat_Click_1(object sender, EventArgs e)
        {
            ThongSoKyThuat thongSoKyThuat = new ThongSoKyThuat();
            thongSoKyThuat.Show();
        }

        private void pictureBox3_MouseEnter_1(object sender, EventArgs e)
        {
            label_ThongTinSanPham.Font = HoverFont;
            label_ThongTinSanPham.ForeColor = Color.Red;
        }

        private void pictureBox3_MouseLeave_1(object sender, EventArgs e)
        {
            label_ThongTinSanPham.Font = ResetFont;
            label_ThongTinSanPham.ForeColor = Color.Black;
        }

        private void pictureBox1_MouseEnter_1(object sender, EventArgs e)
        {
            label_TinhTrangSanPham.Font = HoverFont;
            label_TinhTrangSanPham.ForeColor = Color.Red;
        }

        private void pictureBox1_MouseLeave_1(object sender, EventArgs e)
        {
            label_TinhTrangSanPham.Font = ResetFont;
            label_TinhTrangSanPham.ForeColor = Color.Black;
        }

        private void label_ThongSoKyThuat_MouseEnter_1(object sender, EventArgs e)
        {
            label_ThongSoKyThuat.Font = HoverFont;
            label_ThongSoKyThuat.ForeColor = Color.Red;
        }

        private void label_ThongSoKyThuat_MouseLeave_1(object sender, EventArgs e)
        {
            label_ThongSoKyThuat.Font = ResetFont;
            label_ThongSoKyThuat.ForeColor = Color.Black;
        }
    }
}
