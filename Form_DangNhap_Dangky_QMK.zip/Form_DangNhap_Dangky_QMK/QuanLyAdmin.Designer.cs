﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class QuanLyAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyAdmin));
            groupBox1 = new GroupBox();
            dataGridView_Admin = new DataGridView();
            textBox_MaAdmin = new TextBox();
            label9 = new Label();
            comboBox_GioiTinh = new ComboBox();
            groupBox2 = new GroupBox();
            comboBox_QuyenAdmin = new ComboBox();
            label10 = new Label();
            textBox_EmailAdmin = new TextBox();
            label8 = new Label();
            textBox_HoTenAdmin = new TextBox();
            label7 = new Label();
            dateTimePicker_NgaySinh = new DateTimePicker();
            textbox_MatKhau = new TextBox();
            textbox_TenDangNhap = new TextBox();
            textbox_DienThoaiAdmin = new TextBox();
            textbox_DiaChiAdmin = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            imageList1 = new ImageList(components);
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView_Admin).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            groupBox1.Controls.Add(dataGridView_Admin);
            groupBox1.Location = new Point(12, 277);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(706, 197);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // dataGridView_Admin
            // 
            dataGridView_Admin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_Admin.Location = new Point(18, 22);
            dataGridView_Admin.Name = "dataGridView_Admin";
            dataGridView_Admin.RowTemplate.Height = 25;
            dataGridView_Admin.Size = new Size(670, 156);
            dataGridView_Admin.TabIndex = 0;
            dataGridView_Admin.CellContentClick += dataGridView_Admin_CellContentClick;
            // 
            // textBox_MaAdmin
            // 
            textBox_MaAdmin.Location = new Point(145, 34);
            textBox_MaAdmin.Name = "textBox_MaAdmin";
            textBox_MaAdmin.ReadOnly = true;
            textBox_MaAdmin.Size = new Size(100, 23);
            textBox_MaAdmin.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.White;
            label9.Location = new Point(45, 37);
            label9.Name = "label9";
            label9.Size = new Size(66, 15);
            label9.TabIndex = 14;
            label9.Text = "Mã Admin:";
            // 
            // comboBox_GioiTinh
            // 
            comboBox_GioiTinh.FormattingEnabled = true;
            comboBox_GioiTinh.Location = new Point(450, 121);
            comboBox_GioiTinh.Name = "comboBox_GioiTinh";
            comboBox_GioiTinh.Size = new Size(100, 23);
            comboBox_GioiTinh.TabIndex = 13;
            // 
            // groupBox2
            // 
            groupBox2.BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(comboBox_QuyenAdmin);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(button3);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(button4);
            groupBox2.Controls.Add(textBox_MaAdmin);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(comboBox_GioiTinh);
            groupBox2.Controls.Add(textBox_EmailAdmin);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textBox_HoTenAdmin);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(dateTimePicker_NgaySinh);
            groupBox2.Controls.Add(textbox_MatKhau);
            groupBox2.Controls.Add(textbox_TenDangNhap);
            groupBox2.Controls.Add(textbox_DienThoaiAdmin);
            groupBox2.Controls.Add(textbox_DiaChiAdmin);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(48, 29);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(633, 216);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            // 
            // comboBox_QuyenAdmin
            // 
            comboBox_QuyenAdmin.FormattingEnabled = true;
            comboBox_QuyenAdmin.Items.AddRange(new object[] { "1", "2", "3" });
            comboBox_QuyenAdmin.Location = new Point(450, 150);
            comboBox_QuyenAdmin.Name = "comboBox_QuyenAdmin";
            comboBox_QuyenAdmin.Size = new Size(100, 23);
            comboBox_QuyenAdmin.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.Location = new Point(346, 153);
            label10.Name = "label10";
            label10.Size = new Size(107, 15);
            label10.TabIndex = 16;
            label10.Text = "Quyền hạn Admin:";
            // 
            // textBox_EmailAdmin
            // 
            textBox_EmailAdmin.Location = new Point(145, 150);
            textBox_EmailAdmin.Name = "textBox_EmailAdmin";
            textBox_EmailAdmin.Size = new Size(138, 23);
            textBox_EmailAdmin.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.White;
            label8.Location = new Point(45, 153);
            label8.Name = "label8";
            label8.Size = new Size(78, 15);
            label8.TabIndex = 11;
            label8.Text = "Email Admin:";
            // 
            // textBox_HoTenAdmin
            // 
            textBox_HoTenAdmin.Location = new Point(450, 34);
            textBox_HoTenAdmin.Name = "textBox_HoTenAdmin";
            textBox_HoTenAdmin.Size = new Size(100, 23);
            textBox_HoTenAdmin.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.White;
            label7.Location = new Point(350, 37);
            label7.Name = "label7";
            label7.Size = new Size(85, 15);
            label7.TabIndex = 9;
            label7.Text = "Họ tên Admin:";
            // 
            // dateTimePicker_NgaySinh
            // 
            dateTimePicker_NgaySinh.Format = DateTimePickerFormat.Short;
            dateTimePicker_NgaySinh.ImeMode = ImeMode.NoControl;
            dateTimePicker_NgaySinh.Location = new Point(450, 92);
            dateTimePicker_NgaySinh.Name = "dateTimePicker_NgaySinh";
            dateTimePicker_NgaySinh.Size = new Size(100, 23);
            dateTimePicker_NgaySinh.TabIndex = 8;
            // 
            // textbox_MatKhau
            // 
            textbox_MatKhau.Location = new Point(145, 121);
            textbox_MatKhau.Name = "textbox_MatKhau";
            textbox_MatKhau.Size = new Size(100, 23);
            textbox_MatKhau.TabIndex = 7;
            // 
            // textbox_TenDangNhap
            // 
            textbox_TenDangNhap.Location = new Point(145, 92);
            textbox_TenDangNhap.Name = "textbox_TenDangNhap";
            textbox_TenDangNhap.Size = new Size(100, 23);
            textbox_TenDangNhap.TabIndex = 6;
            // 
            // textbox_DienThoaiAdmin
            // 
            textbox_DienThoaiAdmin.Location = new Point(450, 63);
            textbox_DienThoaiAdmin.Name = "textbox_DienThoaiAdmin";
            textbox_DienThoaiAdmin.Size = new Size(100, 23);
            textbox_DienThoaiAdmin.TabIndex = 5;
            // 
            // textbox_DiaChiAdmin
            // 
            textbox_DiaChiAdmin.Location = new Point(145, 63);
            textbox_DiaChiAdmin.Name = "textbox_DiaChiAdmin";
            textbox_DiaChiAdmin.Size = new Size(100, 23);
            textbox_DiaChiAdmin.TabIndex = 4;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.White;
            label6.Location = new Point(350, 66);
            label6.Name = "label6";
            label6.Size = new Size(103, 15);
            label6.TabIndex = 0;
            label6.Text = "Điện thoại Admin:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.White;
            label5.Location = new Point(45, 66);
            label5.Name = "label5";
            label5.Size = new Size(85, 15);
            label5.TabIndex = 0;
            label5.Text = "Địa chỉ Admin:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Location = new Point(350, 92);
            label4.Name = "label4";
            label4.Size = new Size(63, 15);
            label4.TabIndex = 0;
            label4.Text = "Ngày sinh:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Location = new Point(350, 124);
            label3.Name = "label3";
            label3.Size = new Size(55, 15);
            label3.TabIndex = 0;
            label3.Text = "Giới tính:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Location = new Point(45, 95);
            label2.Name = "label2";
            label2.Size = new Size(88, 15);
            label2.TabIndex = 0;
            label2.Text = "Tên đăng nhập:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Location = new Point(45, 124);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 0;
            label1.Text = "Mật khẩu:";
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // button1
            // 
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.ImageIndex = 0;
            button1.ImageList = imageList1;
            button1.Location = new Point(350, 179);
            button1.Name = "button1";
            button1.Size = new Size(97, 23);
            button1.TabIndex = 10;
            button1.Text = "      Khởi tạo";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button_Khoitao_Click;
            // 
            // button2
            // 
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.ImageIndex = 1;
            button2.ImageList = imageList1;
            button2.Location = new Point(208, 179);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 11;
            button2.Text = "  Xóa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button_Xoa_Click;
            // 
            // button3
            // 
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.ImageIndex = 2;
            button3.ImageList = imageList1;
            button3.Location = new Point(127, 179);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 12;
            button3.Text = "  Sửa";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button_Sua_Click;
            // 
            // button4
            // 
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.ImageIndex = 3;
            button4.ImageList = imageList1;
            button4.Location = new Point(46, 179);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 13;
            button4.Text = "    Thêm";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button_Them_Click;
            // 
            // QuanLyAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(730, 500);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "QuanLyAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "QuanLyAdmin";
            Load += QuanLyAdmin_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView_Admin).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private DataGridView dataGridView_Admin;
        private TextBox textBox_MaAdmin;
        private Label label9;
        private ComboBox comboBox_GioiTinh;
        private GroupBox groupBox2;
        private TextBox textBox_EmailAdmin;
        private Label label8;
        private TextBox textBox_HoTenAdmin;
        private Label label7;
        private DateTimePicker dateTimePicker_NgaySinh;
        private TextBox textbox_MatKhau;
        private TextBox textbox_TenDangNhap;
        private TextBox textbox_DienThoaiAdmin;
        private TextBox textbox_DiaChiAdmin;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox comboBox_QuyenAdmin;
        private Label label10;
        private ImageList imageList1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}