﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class QuanLyKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyKhachHang));
            dataGridView_KhachHang = new DataGridView();
            textBox_HoTenKH = new TextBox();
            label7 = new Label();
            dateTimePicker_NgaySinh = new DateTimePicker();
            textbox_MatKhau = new TextBox();
            textbox_TenDangNhap = new TextBox();
            textbox_DienThoaiKH = new TextBox();
            textbox_DiaChiKH = new TextBox();
            groupBox2 = new GroupBox();
            textBox_MaKH = new TextBox();
            label9 = new Label();
            comboBox_GioiTinh = new ComboBox();
            textBox_Email = new TextBox();
            label8 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            imageList1 = new ImageList(components);
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView_KhachHang).BeginInit();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView_KhachHang
            // 
            dataGridView_KhachHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_KhachHang.Location = new Point(18, 22);
            dataGridView_KhachHang.Name = "dataGridView_KhachHang";
            dataGridView_KhachHang.RowTemplate.Height = 25;
            dataGridView_KhachHang.Size = new Size(689, 156);
            dataGridView_KhachHang.TabIndex = 0;
            dataGridView_KhachHang.CellContentClick += dataGridView_KhachHang_CellContentClick;
            // 
            // textBox_HoTenKH
            // 
            textBox_HoTenKH.Location = new Point(450, 34);
            textBox_HoTenKH.Name = "textBox_HoTenKH";
            textBox_HoTenKH.Size = new Size(100, 23);
            textBox_HoTenKH.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(350, 37);
            label7.Name = "label7";
            label7.Size = new Size(65, 15);
            label7.TabIndex = 9;
            label7.Text = "Họ tên KH:";
            // 
            // dateTimePicker_NgaySinh
            // 
            dateTimePicker_NgaySinh.Format = DateTimePickerFormat.Short;
            dateTimePicker_NgaySinh.ImeMode = ImeMode.NoControl;
            dateTimePicker_NgaySinh.Location = new Point(145, 121);
            dateTimePicker_NgaySinh.Name = "dateTimePicker_NgaySinh";
            dateTimePicker_NgaySinh.Size = new Size(100, 23);
            dateTimePicker_NgaySinh.TabIndex = 8;
            // 
            // textbox_MatKhau
            // 
            textbox_MatKhau.Location = new Point(450, 95);
            textbox_MatKhau.Name = "textbox_MatKhau";
            textbox_MatKhau.Size = new Size(100, 23);
            textbox_MatKhau.TabIndex = 7;
            // 
            // textbox_TenDangNhap
            // 
            textbox_TenDangNhap.Location = new Point(145, 92);
            textbox_TenDangNhap.Name = "textbox_TenDangNhap";
            textbox_TenDangNhap.Size = new Size(100, 23);
            textbox_TenDangNhap.TabIndex = 6;
            // 
            // textbox_DienThoaiKH
            // 
            textbox_DienThoaiKH.Location = new Point(450, 63);
            textbox_DienThoaiKH.Name = "textbox_DienThoaiKH";
            textbox_DienThoaiKH.Size = new Size(100, 23);
            textbox_DienThoaiKH.TabIndex = 5;
            // 
            // textbox_DiaChiKH
            // 
            textbox_DiaChiKH.Location = new Point(145, 63);
            textbox_DiaChiKH.Name = "textbox_DiaChiKH";
            textbox_DiaChiKH.Size = new Size(100, 23);
            textbox_DiaChiKH.TabIndex = 4;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.White;
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(textBox_MaKH);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(button3);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(button4);
            groupBox2.Controls.Add(comboBox_GioiTinh);
            groupBox2.Controls.Add(textBox_Email);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textBox_HoTenKH);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(dateTimePicker_NgaySinh);
            groupBox2.Controls.Add(textbox_MatKhau);
            groupBox2.Controls.Add(textbox_TenDangNhap);
            groupBox2.Controls.Add(textbox_DienThoaiKH);
            groupBox2.Controls.Add(textbox_DiaChiKH);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(51, 46);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(633, 216);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            // 
            // textBox_MaKH
            // 
            textBox_MaKH.Location = new Point(145, 34);
            textBox_MaKH.Name = "textBox_MaKH";
            textBox_MaKH.ReadOnly = true;
            textBox_MaKH.Size = new Size(100, 23);
            textBox_MaKH.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(45, 37);
            label9.Name = "label9";
            label9.Size = new Size(46, 15);
            label9.TabIndex = 14;
            label9.Text = "Mã KH:";
            // 
            // comboBox_GioiTinh
            // 
            comboBox_GioiTinh.FormattingEnabled = true;
            comboBox_GioiTinh.Location = new Point(450, 124);
            comboBox_GioiTinh.Name = "comboBox_GioiTinh";
            comboBox_GioiTinh.Size = new Size(100, 23);
            comboBox_GioiTinh.TabIndex = 13;
            // 
            // textBox_Email
            // 
            textBox_Email.Location = new Point(145, 150);
            textBox_Email.Name = "textBox_Email";
            textBox_Email.Size = new Size(138, 23);
            textBox_Email.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(45, 153);
            label8.Name = "label8";
            label8.Size = new Size(39, 15);
            label8.TabIndex = 11;
            label8.Text = "Email:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(350, 66);
            label6.Name = "label6";
            label6.Size = new Size(83, 15);
            label6.TabIndex = 0;
            label6.Text = "Điện thoại KH:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(45, 66);
            label5.Name = "label5";
            label5.Size = new Size(65, 15);
            label5.TabIndex = 0;
            label5.Text = "Địa chỉ KH:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(45, 121);
            label4.Name = "label4";
            label4.Size = new Size(63, 15);
            label4.TabIndex = 0;
            label4.Text = "Ngày sinh:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(350, 127);
            label3.Name = "label3";
            label3.Size = new Size(55, 15);
            label3.TabIndex = 0;
            label3.Text = "Giới tính:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(45, 95);
            label2.Name = "label2";
            label2.Size = new Size(88, 15);
            label2.TabIndex = 0;
            label2.Text = "Tên đăng nhập:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(350, 98);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 0;
            label1.Text = "Mật khẩu:";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(dataGridView_KhachHang);
            groupBox1.Location = new Point(3, 291);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(724, 197);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // button1
            // 
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.ImageIndex = 0;
            button1.ImageList = imageList1;
            button1.Location = new Point(350, 179);
            button1.Name = "button1";
            button1.Size = new Size(97, 23);
            button1.TabIndex = 6;
            button1.Text = "      Khởi tạo";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button_Khoitao_Click;
            // 
            // button2
            // 
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.ImageIndex = 1;
            button2.ImageList = imageList1;
            button2.Location = new Point(208, 179);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 7;
            button2.Text = "  Xóa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button_Xoa_Click;
            // 
            // button3
            // 
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.ImageIndex = 2;
            button3.ImageList = imageList1;
            button3.Location = new Point(127, 179);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 8;
            button3.Text = "  Sửa";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button_Sua_Click;
            // 
            // button4
            // 
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.ImageIndex = 3;
            button4.ImageList = imageList1;
            button4.Location = new Point(46, 179);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 9;
            button4.Text = "    Thêm";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button_Them_Click;
            // 
            // QuanLyKhachHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(730, 500);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "QuanLyKhachHang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "QuanLyKhachHang";
            Load += QuanLyKhachHang_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_KhachHang).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView_KhachHang;
        private TextBox textBox_HoTenKH;
        private Label label7;
        private DateTimePicker dateTimePicker_NgaySinh;
        private TextBox textbox_MatKhau;
        private TextBox textbox_TenDangNhap;
        private TextBox textbox_DienThoaiKH;
        private TextBox textbox_DiaChiKH;
        private GroupBox groupBox2;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox1;
        private TextBox textBox_Email;
        private Label label8;
        private ComboBox comboBox_GioiTinh;
        private TextBox textBox_MaKH;
        private Label label9;
        private ImageList imageList1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}