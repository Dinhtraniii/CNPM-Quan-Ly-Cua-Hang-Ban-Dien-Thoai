﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class TinhTrangSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TinhTrangSanPham));
            dataGridView_TTSanPham = new DataGridView();
            textBox_MaSP = new TextBox();
            label7 = new Label();
            textbox_HinhMinhHoa = new TextBox();
            textbox_TenDienThoai = new TextBox();
            groupBox2 = new GroupBox();
            comboBox_TinhTrang = new ComboBox();
            comboBox_LoaiSanPham = new ComboBox();
            textbox_ThongTin = new TextBox();
            label2 = new Label();
            label6 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            dangNhapBindingSource = new BindingSource(components);
            button1 = new Button();
            button2 = new Button();
            imageList1 = new ImageList(components);
            imageList2 = new ImageList(components);
            ((System.ComponentModel.ISupportInitialize)dataGridView_TTSanPham).BeginInit();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dangNhapBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView_TTSanPham
            // 
            dataGridView_TTSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_TTSanPham.Location = new Point(16, 22);
            dataGridView_TTSanPham.Name = "dataGridView_TTSanPham";
            dataGridView_TTSanPham.RowTemplate.Height = 25;
            dataGridView_TTSanPham.Size = new Size(317, 342);
            dataGridView_TTSanPham.TabIndex = 0;
            dataGridView_TTSanPham.CellContentClick += dataGridView_TTSanPham_CellContentClick;
            // 
            // textBox_MaSP
            // 
            textBox_MaSP.Location = new Point(145, 47);
            textBox_MaSP.Name = "textBox_MaSP";
            textBox_MaSP.ReadOnly = true;
            textBox_MaSP.Size = new Size(100, 23);
            textBox_MaSP.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(45, 50);
            label7.Name = "label7";
            label7.Size = new Size(82, 15);
            label7.TabIndex = 9;
            label7.Text = "Mã sản phẩm:";
            // 
            // textbox_HinhMinhHoa
            // 
            textbox_HinhMinhHoa.Location = new Point(145, 135);
            textbox_HinhMinhHoa.Name = "textbox_HinhMinhHoa";
            textbox_HinhMinhHoa.ReadOnly = true;
            textbox_HinhMinhHoa.Size = new Size(100, 23);
            textbox_HinhMinhHoa.TabIndex = 7;
            // 
            // textbox_TenDienThoai
            // 
            textbox_TenDienThoai.Location = new Point(145, 90);
            textbox_TenDienThoai.Name = "textbox_TenDienThoai";
            textbox_TenDienThoai.ReadOnly = true;
            textbox_TenDienThoai.Size = new Size(100, 23);
            textbox_TenDienThoai.TabIndex = 5;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.White;
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(comboBox_TinhTrang);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(comboBox_LoaiSanPham);
            groupBox2.Controls.Add(textbox_ThongTin);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(textBox_MaSP);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(textbox_HinhMinhHoa);
            groupBox2.Controls.Add(textbox_TenDienThoai);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(21, 6);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(291, 377);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            // 
            // comboBox_TinhTrang
            // 
            comboBox_TinhTrang.FormattingEnabled = true;
            comboBox_TinhTrang.Location = new Point(145, 215);
            comboBox_TinhTrang.Name = "comboBox_TinhTrang";
            comboBox_TinhTrang.Size = new Size(100, 23);
            comboBox_TinhTrang.TabIndex = 15;
            // 
            // comboBox_LoaiSanPham
            // 
            comboBox_LoaiSanPham.FormattingEnabled = true;
            comboBox_LoaiSanPham.Items.AddRange(new object[] { "a", "b", "c" });
            comboBox_LoaiSanPham.Location = new Point(145, 177);
            comboBox_LoaiSanPham.Name = "comboBox_LoaiSanPham";
            comboBox_LoaiSanPham.Size = new Size(100, 23);
            comboBox_LoaiSanPham.TabIndex = 14;
            // 
            // textbox_ThongTin
            // 
            textbox_ThongTin.Location = new Point(145, 253);
            textbox_ThongTin.Multiline = true;
            textbox_ThongTin.Name = "textbox_ThongTin";
            textbox_ThongTin.Size = new Size(140, 82);
            textbox_ThongTin.TabIndex = 13;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 285);
            label2.Name = "label2";
            label2.Size = new Size(116, 15);
            label2.TabIndex = 12;
            label2.Text = "Thông tin sản phẩm:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(45, 93);
            label6.Name = "label6";
            label6.Size = new Size(84, 15);
            label6.TabIndex = 0;
            label6.Text = "Tên điện thoại:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(45, 177);
            label4.Name = "label4";
            label4.Size = new Size(87, 15);
            label4.TabIndex = 0;
            label4.Text = "Loại sản phẩm:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 218);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 0;
            label3.Text = "Tình trạng:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 138);
            label1.Name = "label1";
            label1.Size = new Size(90, 15);
            label1.TabIndex = 0;
            label1.Text = "Hình minh họa:";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(dataGridView_TTSanPham);
            groupBox1.Location = new Point(335, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(351, 377);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // dangNhapBindingSource
            // 
            dangNhapBindingSource.DataSource = typeof(DangNhap);
            // 
            // button1
            // 
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.ImageIndex = 0;
            button1.ImageList = imageList1;
            button1.Location = new Point(145, 341);
            button1.Name = "button1";
            button1.Size = new Size(97, 23);
            button1.TabIndex = 10;
            button1.Text = "      Khởi tạo";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button_Khoitao_Click;
            // 
            // button2
            // 
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.ImageIndex = 2;
            button2.ImageList = imageList1;
            button2.Location = new Point(45, 341);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 11;
            button2.Text = "  Sửa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button_Sua_Click;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // imageList2
            // 
            imageList2.ColorDepth = ColorDepth.Depth8Bit;
            imageList2.ImageStream = (ImageListStreamer)resources.GetObject("imageList2.ImageStream");
            imageList2.TransparentColor = Color.Transparent;
            imageList2.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList2.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList2.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList2.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // TinhTrangSanPham
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(706, 389);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "TinhTrangSanPham";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tình trạng sản phẩm";
            Load += TinhTrangSanPham_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_TTSanPham).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dangNhapBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView_TTSanPham;
        private TextBox textBox_MaSP;
        private Label label7;
        private DateTimePicker dateTimePicker_NgayCapNhat;
        private TextBox textbox_HinhMinhHoa;
        private TextBox textbox_DonGia;
        private TextBox textbox_TenDienThoai;
        private GroupBox groupBox2;
        private Label label6;
        private Label label4;
        private Label label3;
        private Label label1;
        private GroupBox groupBox1;
        private TextBox textbox_ThongTin;
        private Label label2;
        private ComboBox comboBox_TinhTrang;
        private ComboBox comboBox_LoaiSanPham;
        private BindingSource dangNhapBindingSource;
        private Button button1;
        private Button button2;
        private ImageList imageList1;
        private ImageList imageList2;
    }
}