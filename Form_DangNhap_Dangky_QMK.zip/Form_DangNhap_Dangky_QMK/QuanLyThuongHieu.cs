﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class QuanLyThuongHieu : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select * from THUONGHIEU";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_ThuongHieu.DataSource = table;
        }
        public QuanLyThuongHieu()
        {
            InitializeComponent();
        }

        private void dataGridView_ThuongHieu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_ThuongHieu.CurrentRow.Index;
            textBox_MaThuongHieu.Text = dataGridView_ThuongHieu.Rows[i].Cells[0].Value.ToString();
            textbox_TenThuongHieu.Text = dataGridView_ThuongHieu.Rows[i].Cells[1].Value.ToString();
            textbox_HinhMinhHoa.Text = dataGridView_ThuongHieu.Rows[i].Cells[2].Value.ToString();
        }

        private void QuanLyThuongHieu_Load(object sender, EventArgs e)
        {
            sqlConnection.Open();
            loaddata();
        }

        private void button_Them_Click(object sender, EventArgs e)
        {
            if (textbox_TenThuongHieu.Text == "" || textbox_HinhMinhHoa.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "insert into THUONGHIEU(TenTH, HinhMinhHoa) values('" + textbox_TenThuongHieu.Text + "','" + textbox_HinhMinhHoa.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã thêm dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            if (textbox_TenThuongHieu.Text == "" || textbox_HinhMinhHoa.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update THUONGHIEU set TenTH = '" + textbox_TenThuongHieu.Text + "', HinhMinhHoa = '" + textbox_HinhMinhHoa.Text + "' where MaTH = '" + textBox_MaThuongHieu.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            if (textbox_TenThuongHieu.Text == "" || textbox_HinhMinhHoa.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "delete from THUONGHIEU where MaTH= '" + textBox_MaThuongHieu.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã xóa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textbox_HinhMinhHoa.Clear();
            textBox_MaThuongHieu.Clear();
            textbox_TenThuongHieu.Clear();
        }
    }
}
