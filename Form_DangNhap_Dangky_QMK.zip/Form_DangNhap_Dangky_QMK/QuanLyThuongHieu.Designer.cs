﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class QuanLyThuongHieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyThuongHieu));
            dataGridView_ThuongHieu = new DataGridView();
            textbox_HinhMinhHoa = new TextBox();
            textbox_TenThuongHieu = new TextBox();
            label6 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            textBox_MaThuongHieu = new TextBox();
            label2 = new Label();
            groupBox1 = new GroupBox();
            button_Khoitao = new Button();
            button_Xoa = new Button();
            button_Sua = new Button();
            button_Them = new Button();
            imageList1 = new ImageList(components);
            ((System.ComponentModel.ISupportInitialize)dataGridView_ThuongHieu).BeginInit();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView_ThuongHieu
            // 
            dataGridView_ThuongHieu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_ThuongHieu.Location = new Point(16, 22);
            dataGridView_ThuongHieu.Name = "dataGridView_ThuongHieu";
            dataGridView_ThuongHieu.RowTemplate.Height = 25;
            dataGridView_ThuongHieu.Size = new Size(654, 177);
            dataGridView_ThuongHieu.TabIndex = 0;
            dataGridView_ThuongHieu.CellContentClick += dataGridView_ThuongHieu_CellContentClick;
            // 
            // textbox_HinhMinhHoa
            // 
            textbox_HinhMinhHoa.Location = new Point(145, 150);
            textbox_HinhMinhHoa.Name = "textbox_HinhMinhHoa";
            textbox_HinhMinhHoa.Size = new Size(100, 23);
            textbox_HinhMinhHoa.TabIndex = 7;
            // 
            // textbox_TenThuongHieu
            // 
            textbox_TenThuongHieu.Location = new Point(145, 93);
            textbox_TenThuongHieu.Name = "textbox_TenThuongHieu";
            textbox_TenThuongHieu.Size = new Size(100, 23);
            textbox_TenThuongHieu.TabIndex = 5;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(45, 96);
            label6.Name = "label6";
            label6.Size = new Size(96, 15);
            label6.TabIndex = 0;
            label6.Text = "Tên thương hiệu:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 153);
            label1.Name = "label1";
            label1.Size = new Size(90, 15);
            label1.TabIndex = 0;
            label1.Text = "Hình minh họa:";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.White;
            groupBox2.Controls.Add(button_Khoitao);
            groupBox2.Controls.Add(textBox_MaThuongHieu);
            groupBox2.Controls.Add(button_Xoa);
            groupBox2.Controls.Add(button_Sua);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(button_Them);
            groupBox2.Controls.Add(textbox_HinhMinhHoa);
            groupBox2.Controls.Add(textbox_TenThuongHieu);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(21, 29);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(688, 203);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            // 
            // textBox_MaThuongHieu
            // 
            textBox_MaThuongHieu.Location = new Point(145, 36);
            textBox_MaThuongHieu.Name = "textBox_MaThuongHieu";
            textBox_MaThuongHieu.ReadOnly = true;
            textBox_MaThuongHieu.Size = new Size(100, 23);
            textBox_MaThuongHieu.TabIndex = 15;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(45, 39);
            label2.Name = "label2";
            label2.Size = new Size(95, 15);
            label2.TabIndex = 14;
            label2.Text = "Mã thương hiệu:";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(dataGridView_ThuongHieu);
            groupBox1.Location = new Point(21, 272);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(688, 216);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // button_Khoitao
            // 
            button_Khoitao.ImageAlign = ContentAlignment.MiddleLeft;
            button_Khoitao.ImageIndex = 0;
            button_Khoitao.ImageList = imageList1;
            button_Khoitao.Location = new Point(449, 126);
            button_Khoitao.Name = "button_Khoitao";
            button_Khoitao.Size = new Size(97, 23);
            button_Khoitao.TabIndex = 10;
            button_Khoitao.Text = "      Khởi tạo";
            button_Khoitao.UseVisualStyleBackColor = true;
            button_Khoitao.Click += button_Khoitao_Click;
            // 
            // button_Xoa
            // 
            button_Xoa.ImageAlign = ContentAlignment.MiddleLeft;
            button_Xoa.ImageIndex = 1;
            button_Xoa.ImageList = imageList1;
            button_Xoa.Location = new Point(542, 88);
            button_Xoa.Name = "button_Xoa";
            button_Xoa.Size = new Size(75, 23);
            button_Xoa.TabIndex = 11;
            button_Xoa.Text = "  Xóa";
            button_Xoa.UseVisualStyleBackColor = true;
            button_Xoa.Click += button_Xoa_Click;
            // 
            // button_Sua
            // 
            button_Sua.ImageAlign = ContentAlignment.MiddleLeft;
            button_Sua.ImageIndex = 2;
            button_Sua.ImageList = imageList1;
            button_Sua.Location = new Point(461, 88);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 23);
            button_Sua.TabIndex = 12;
            button_Sua.Text = "  Sửa";
            button_Sua.UseVisualStyleBackColor = true;
            button_Sua.Click += button_Sua_Click;
            // 
            // button_Them
            // 
            button_Them.ImageAlign = ContentAlignment.MiddleLeft;
            button_Them.ImageIndex = 3;
            button_Them.ImageList = imageList1;
            button_Them.Location = new Point(380, 88);
            button_Them.Name = "button_Them";
            button_Them.Size = new Size(75, 23);
            button_Them.TabIndex = 13;
            button_Them.Text = "    Thêm";
            button_Them.UseVisualStyleBackColor = true;
            button_Them.Click += button_Them_Click;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // QuanLyThuongHieu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(730, 500);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "QuanLyThuongHieu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "QuanLyThuongHieu";
            Load += QuanLyThuongHieu_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_ThuongHieu).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView_ThuongHieu;
        private TextBox textbox_HinhMinhHoa;
        private TextBox textbox_TenThuongHieu;
        private Label label6;
        private Label label1;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private TextBox textBox_MaThuongHieu;
        private Label label2;
        private Button button_Khoitao;
        private Button button_Xoa;
        private Button button_Sua;
        private Button button_Them;
        private ImageList imageList1;
    }
}