﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class QuanLyDonHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyDonHang));
            groupBox1 = new GroupBox();
            dataGridView_QLDonHang = new DataGridView();
            textBox_SoDH = new TextBox();
            label9 = new Label();
            comboBox_DaThanhToan = new ComboBox();
            groupBox2 = new GroupBox();
            comboBox_DaGiaoHang = new ComboBox();
            label11 = new Label();
            dateTimePicker_NgayGiaoHang = new DateTimePicker();
            label10 = new Label();
            textBox_TenNguoiNhan = new TextBox();
            label7 = new Label();
            dateTimePicker_NgayDatHang = new DateTimePicker();
            textbox_DienThoaiNhan = new TextBox();
            textbox_TriGia = new TextBox();
            textbox_DiaChiNhan = new TextBox();
            textbox_MaKH = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            imageList1 = new ImageList(components);
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView_QLDonHang).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(dataGridView_QLDonHang);
            groupBox1.Location = new Point(3, 281);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(724, 197);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // dataGridView_QLDonHang
            // 
            dataGridView_QLDonHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_QLDonHang.Location = new Point(18, 22);
            dataGridView_QLDonHang.Name = "dataGridView_QLDonHang";
            dataGridView_QLDonHang.RowTemplate.Height = 25;
            dataGridView_QLDonHang.Size = new Size(689, 156);
            dataGridView_QLDonHang.TabIndex = 0;
            dataGridView_QLDonHang.CellContentClick += dataGridView_QLDonHang_CellContentClick;
            // 
            // textBox_SoDH
            // 
            textBox_SoDH.Location = new Point(144, 22);
            textBox_SoDH.Name = "textBox_SoDH";
            textBox_SoDH.ReadOnly = true;
            textBox_SoDH.Size = new Size(100, 23);
            textBox_SoDH.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(44, 25);
            label9.Name = "label9";
            label9.Size = new Size(43, 15);
            label9.TabIndex = 14;
            label9.Text = "Số ĐH:";
            // 
            // comboBox_DaThanhToan
            // 
            comboBox_DaThanhToan.FormattingEnabled = true;
            comboBox_DaThanhToan.Location = new Point(446, 112);
            comboBox_DaThanhToan.Name = "comboBox_DaThanhToan";
            comboBox_DaThanhToan.Size = new Size(100, 23);
            comboBox_DaThanhToan.TabIndex = 13;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.White;
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(comboBox_DaGiaoHang);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(button3);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(button4);
            groupBox2.Controls.Add(dateTimePicker_NgayGiaoHang);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(textBox_SoDH);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(comboBox_DaThanhToan);
            groupBox2.Controls.Add(textBox_TenNguoiNhan);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(dateTimePicker_NgayDatHang);
            groupBox2.Controls.Add(textbox_DienThoaiNhan);
            groupBox2.Controls.Add(textbox_TriGia);
            groupBox2.Controls.Add(textbox_DiaChiNhan);
            groupBox2.Controls.Add(textbox_MaKH);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(48, 36);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(633, 216);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // comboBox_DaGiaoHang
            // 
            comboBox_DaGiaoHang.FormattingEnabled = true;
            comboBox_DaGiaoHang.Location = new Point(446, 141);
            comboBox_DaGiaoHang.Name = "comboBox_DaGiaoHang";
            comboBox_DaGiaoHang.Size = new Size(100, 23);
            comboBox_DaGiaoHang.TabIndex = 20;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(346, 144);
            label11.Name = "label11";
            label11.Size = new Size(80, 15);
            label11.TabIndex = 19;
            label11.Text = "Đã giao hàng:";
            // 
            // dateTimePicker_NgayGiaoHang
            // 
            dateTimePicker_NgayGiaoHang.Format = DateTimePickerFormat.Short;
            dateTimePicker_NgayGiaoHang.ImeMode = ImeMode.NoControl;
            dateTimePicker_NgayGiaoHang.Location = new Point(144, 139);
            dateTimePicker_NgayGiaoHang.Name = "dateTimePicker_NgayGiaoHang";
            dateTimePicker_NgayGiaoHang.Size = new Size(100, 23);
            dateTimePicker_NgayGiaoHang.TabIndex = 18;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(44, 139);
            label10.Name = "label10";
            label10.Size = new Size(94, 15);
            label10.TabIndex = 17;
            label10.Text = "Ngày giao hàng:";
            // 
            // textBox_TenNguoiNhan
            // 
            textBox_TenNguoiNhan.Location = new Point(446, 22);
            textBox_TenNguoiNhan.Name = "textBox_TenNguoiNhan";
            textBox_TenNguoiNhan.Size = new Size(100, 23);
            textBox_TenNguoiNhan.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(346, 25);
            label7.Name = "label7";
            label7.Size = new Size(92, 15);
            label7.TabIndex = 9;
            label7.Text = "Tên người nhận:";
            // 
            // dateTimePicker_NgayDatHang
            // 
            dateTimePicker_NgayDatHang.Format = DateTimePickerFormat.Short;
            dateTimePicker_NgayDatHang.ImeMode = ImeMode.NoControl;
            dateTimePicker_NgayDatHang.Location = new Point(144, 107);
            dateTimePicker_NgayDatHang.Name = "dateTimePicker_NgayDatHang";
            dateTimePicker_NgayDatHang.Size = new Size(100, 23);
            dateTimePicker_NgayDatHang.TabIndex = 8;
            // 
            // textbox_DienThoaiNhan
            // 
            textbox_DienThoaiNhan.Location = new Point(446, 83);
            textbox_DienThoaiNhan.Name = "textbox_DienThoaiNhan";
            textbox_DienThoaiNhan.Size = new Size(100, 23);
            textbox_DienThoaiNhan.TabIndex = 7;
            // 
            // textbox_TriGia
            // 
            textbox_TriGia.Location = new Point(144, 78);
            textbox_TriGia.Name = "textbox_TriGia";
            textbox_TriGia.Size = new Size(100, 23);
            textbox_TriGia.TabIndex = 6;
            // 
            // textbox_DiaChiNhan
            // 
            textbox_DiaChiNhan.Location = new Point(446, 51);
            textbox_DiaChiNhan.Name = "textbox_DiaChiNhan";
            textbox_DiaChiNhan.Size = new Size(100, 23);
            textbox_DiaChiNhan.TabIndex = 5;
            // 
            // textbox_MaKH
            // 
            textbox_MaKH.Location = new Point(144, 51);
            textbox_MaKH.Name = "textbox_MaKH";
            textbox_MaKH.Size = new Size(100, 23);
            textbox_MaKH.TabIndex = 4;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(346, 54);
            label6.Name = "label6";
            label6.Size = new Size(76, 15);
            label6.TabIndex = 0;
            label6.Text = "Địa chỉ nhận:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(44, 54);
            label5.Name = "label5";
            label5.Size = new Size(46, 15);
            label5.TabIndex = 0;
            label5.Text = "Mã KH:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(44, 107);
            label4.Name = "label4";
            label4.Size = new Size(88, 15);
            label4.TabIndex = 0;
            label4.Text = "Ngày đặt hàng:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(346, 115);
            label3.Name = "label3";
            label3.Size = new Size(85, 15);
            label3.TabIndex = 0;
            label3.Text = "Đã thanh toán:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(44, 81);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 0;
            label2.Text = "Trị giá:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(346, 86);
            label1.Name = "label1";
            label1.Size = new Size(94, 15);
            label1.TabIndex = 0;
            label1.Text = "Điện thoại nhận:";
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // button1
            // 
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.ImageIndex = 0;
            button1.ImageList = imageList1;
            button1.Location = new Point(346, 178);
            button1.Name = "button1";
            button1.Size = new Size(97, 23);
            button1.TabIndex = 10;
            button1.Text = "      Khởi tạo";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button_Khoitao_Click;
            // 
            // button2
            // 
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.ImageIndex = 1;
            button2.ImageList = imageList1;
            button2.Location = new Point(206, 178);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 11;
            button2.Text = "  Xóa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button_Xoa_Click;
            // 
            // button3
            // 
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.ImageIndex = 2;
            button3.ImageList = imageList1;
            button3.Location = new Point(125, 178);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 12;
            button3.Text = "  Sửa";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button_Sua_Click;
            // 
            // button4
            // 
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.ImageIndex = 3;
            button4.ImageList = imageList1;
            button4.Location = new Point(44, 178);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 13;
            button4.Text = "    Thêm";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button_Them_Click;
            // 
            // QuanLyDonHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(730, 500);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "QuanLyDonHang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "QuanLyDonHang";
            Load += QuanLyDonHang_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView_QLDonHang).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private DataGridView dataGridView_QLDonHang;
        private TextBox textBox_SoDH;
        private Label label9;
        private ComboBox comboBox_DaThanhToan;
        private GroupBox groupBox2;
        private TextBox textBox_TenNguoiNhan;
        private Label label7;
        private DateTimePicker dateTimePicker_NgayDatHang;
        private TextBox textbox_DienThoaiNhan;
        private TextBox textbox_TriGia;
        private TextBox textbox_DiaChiNhan;
        private TextBox textbox_MaKH;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DateTimePicker dateTimePicker_NgayGiaoHang;
        private Label label10;
        private ComboBox comboBox_DaGiaoHang;
        private Label label11;
        private ImageList imageList1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}