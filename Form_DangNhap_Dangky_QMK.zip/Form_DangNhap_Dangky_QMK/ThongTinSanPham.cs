﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class ThongTinSanPham : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select MaSP, TenSP, DonViTinh, DonGia, HinhMinhHoa, NgayCapNhat,SoLuongBan From SANPHAM";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_SanPham.DataSource = table;
        }
        public ThongTinSanPham()
        {
            InitializeComponent();
        }

        private void dataGridView_SanPham_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_SanPham.CurrentRow.Index;
            textBox_MaSP.Text = dataGridView_SanPham.Rows[i].Cells[0].Value.ToString();
            textbox_TenDienThoai.Text = dataGridView_SanPham.Rows[i].Cells[1].Value.ToString();
            textbox_DonViTinh.Text = dataGridView_SanPham.Rows[i].Cells[2].Value.ToString();
            textbox_DonGia.Text = dataGridView_SanPham.Rows[i].Cells[3].Value.ToString();
            textbox_HinhMinhHoa.Text = dataGridView_SanPham.Rows[i].Cells[4].Value.ToString();
            dateTimePicker_NgayCapNhat.Text = dataGridView_SanPham.Rows[i].Cells[5].Value.ToString();
            textbox_SoLuong.Text = dataGridView_SanPham.Rows[i].Cells[6].Value.ToString();
        }

        private void ThongTinSanPham_Load(object sender, EventArgs e)
        {
            sqlConnection.Open();
            loaddata();
        }
        private void button_Them_Click(object sender, EventArgs e)
        {
            if (textbox_TenDienThoai.Text == "" || textbox_DonViTinh.Text == "" || textbox_DonGia.Text == "" || textbox_HinhMinhHoa.Text == "" || dateTimePicker_NgayCapNhat.Text == "" || textbox_SoLuong.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "insert into SANPHAM(TenSP, DonViTinh, DonGia, HinhMinhHoa, NgayCapNhat, SoLuongBan) values('" + textbox_TenDienThoai.Text + "','" + textbox_DonViTinh.Text + "','" + textbox_DonGia.Text + "','" + textbox_HinhMinhHoa.Text + "','" + dateTimePicker_NgayCapNhat.Text + "','" + textbox_SoLuong.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã thêm dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            if (textbox_TenDienThoai.Text == "" || textbox_DonViTinh.Text == "" || textbox_DonGia.Text == "" || textbox_HinhMinhHoa.Text == "" || dateTimePicker_NgayCapNhat.Text == "" || textbox_SoLuong.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update SANPHAM set TenSP = '" + textbox_TenDienThoai.Text + "', DonViTinh = '" + textbox_DonViTinh.Text + "', DonGia= '" + textbox_DonGia.Text + "', HinhMinhHoa = '" + textbox_HinhMinhHoa.Text + "', NgayCapNhat = '" + dateTimePicker_NgayCapNhat.Text + "', SoLuongBan = '" + textbox_SoLuong.Text + "'  where MaSP = '" + textBox_MaSP.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            if (textbox_TenDienThoai.Text == "" || textbox_DonViTinh.Text == "" || textbox_DonGia.Text == "" || textbox_HinhMinhHoa.Text == "" || dateTimePicker_NgayCapNhat.Text == "" || textbox_SoLuong.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "delete from SANPHAM where MaSP= '" + textBox_MaSP.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã xóa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textBox_MaSP.Text = null;
            textbox_TenDienThoai.Text = null;
            textbox_DonViTinh.Text = null;
            textbox_DonGia.Text = null;
            textbox_HinhMinhHoa.Clear();
            textbox_SoLuong.Clear();
            dateTimePicker_NgayCapNhat.ResetText();
        }
    }
}
