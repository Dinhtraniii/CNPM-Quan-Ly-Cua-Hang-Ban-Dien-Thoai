﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class ThongTinSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinSanPham));
            button_Khoitao = new Button();
            button_Xoa = new Button();
            button_Sua = new Button();
            button_Them = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            textbox_SoLuong = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            textBox_MaSP = new TextBox();
            label7 = new Label();
            dateTimePicker_NgayCapNhat = new DateTimePicker();
            textbox_HinhMinhHoa = new TextBox();
            textbox_DonGia = new TextBox();
            textbox_TenDienThoai = new TextBox();
            textbox_DonViTinh = new TextBox();
            groupBox1 = new GroupBox();
            dataGridView_SanPham = new DataGridView();
            imageList1 = new ImageList(components);
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView_SanPham).BeginInit();
            SuspendLayout();
            // 
            // button_Khoitao
            // 
            button_Khoitao.ImageAlign = ContentAlignment.MiddleLeft;
            button_Khoitao.ImageIndex = 0;
            button_Khoitao.ImageList = imageList1;
            button_Khoitao.Location = new Point(95, 348);
            button_Khoitao.Name = "button_Khoitao";
            button_Khoitao.Size = new Size(97, 23);
            button_Khoitao.TabIndex = 3;
            button_Khoitao.Text = "      Khởi tạo";
            button_Khoitao.UseVisualStyleBackColor = true;
            button_Khoitao.Click += button_Khoitao_Click;
            // 
            // button_Xoa
            // 
            button_Xoa.ImageAlign = ContentAlignment.MiddleLeft;
            button_Xoa.ImageIndex = 1;
            button_Xoa.ImageList = imageList1;
            button_Xoa.Location = new Point(188, 310);
            button_Xoa.Name = "button_Xoa";
            button_Xoa.Size = new Size(75, 23);
            button_Xoa.TabIndex = 3;
            button_Xoa.Text = "  Xóa";
            button_Xoa.UseVisualStyleBackColor = true;
            button_Xoa.Click += button_Xoa_Click;
            // 
            // button_Sua
            // 
            button_Sua.ImageAlign = ContentAlignment.MiddleLeft;
            button_Sua.ImageIndex = 2;
            button_Sua.ImageList = imageList1;
            button_Sua.Location = new Point(107, 310);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 23);
            button_Sua.TabIndex = 3;
            button_Sua.Text = "  Sửa";
            button_Sua.UseVisualStyleBackColor = true;
            button_Sua.Click += button_Sua_Click;
            // 
            // button_Them
            // 
            button_Them.ImageAlign = ContentAlignment.MiddleLeft;
            button_Them.ImageIndex = 3;
            button_Them.ImageList = imageList1;
            button_Them.Location = new Point(26, 310);
            button_Them.Name = "button_Them";
            button_Them.Size = new Size(75, 23);
            button_Them.TabIndex = 3;
            button_Them.Text = "    Thêm";
            button_Them.UseVisualStyleBackColor = true;
            button_Them.Click += button_Them_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(46, 107);
            label6.Name = "label6";
            label6.Size = new Size(84, 15);
            label6.TabIndex = 0;
            label6.Text = "Tên điện thoại:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(46, 66);
            label5.Name = "label5";
            label5.Size = new Size(68, 15);
            label5.TabIndex = 0;
            label5.Text = "Đơn vị tính:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(46, 230);
            label4.Name = "label4";
            label4.Size = new Size(87, 15);
            label4.TabIndex = 0;
            label4.Text = "Ngày cập nhật:";
            // 
            // textbox_SoLuong
            // 
            textbox_SoLuong.Location = new Point(146, 269);
            textbox_SoLuong.Name = "textbox_SoLuong";
            textbox_SoLuong.Size = new Size(100, 23);
            textbox_SoLuong.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 272);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 0;
            label3.Text = "Số lượng:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 147);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 0;
            label2.Text = "Đơn giá:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(46, 189);
            label1.Name = "label1";
            label1.Size = new Size(90, 15);
            label1.TabIndex = 0;
            label1.Text = "Hình minh họa:";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.White;
            groupBox2.Controls.Add(textBox_MaSP);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(dateTimePicker_NgayCapNhat);
            groupBox2.Controls.Add(textbox_HinhMinhHoa);
            groupBox2.Controls.Add(textbox_DonGia);
            groupBox2.Controls.Add(textbox_TenDienThoai);
            groupBox2.Controls.Add(textbox_DonViTinh);
            groupBox2.Controls.Add(button_Khoitao);
            groupBox2.Controls.Add(button_Xoa);
            groupBox2.Controls.Add(button_Sua);
            groupBox2.Controls.Add(button_Them);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(textbox_SoLuong);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(21, 23);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(291, 377);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            // 
            // textBox_MaSP
            // 
            textBox_MaSP.Location = new Point(146, 22);
            textBox_MaSP.Name = "textBox_MaSP";
            textBox_MaSP.ReadOnly = true;
            textBox_MaSP.Size = new Size(100, 23);
            textBox_MaSP.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(46, 25);
            label7.Name = "label7";
            label7.Size = new Size(82, 15);
            label7.TabIndex = 9;
            label7.Text = "Mã sản phẩm:";
            // 
            // dateTimePicker_NgayCapNhat
            // 
            dateTimePicker_NgayCapNhat.Format = DateTimePickerFormat.Short;
            dateTimePicker_NgayCapNhat.ImeMode = ImeMode.NoControl;
            dateTimePicker_NgayCapNhat.Location = new Point(146, 230);
            dateTimePicker_NgayCapNhat.Name = "dateTimePicker_NgayCapNhat";
            dateTimePicker_NgayCapNhat.Size = new Size(100, 23);
            dateTimePicker_NgayCapNhat.TabIndex = 8;
            // 
            // textbox_HinhMinhHoa
            // 
            textbox_HinhMinhHoa.Location = new Point(146, 186);
            textbox_HinhMinhHoa.Name = "textbox_HinhMinhHoa";
            textbox_HinhMinhHoa.Size = new Size(100, 23);
            textbox_HinhMinhHoa.TabIndex = 7;
            // 
            // textbox_DonGia
            // 
            textbox_DonGia.Location = new Point(146, 144);
            textbox_DonGia.Name = "textbox_DonGia";
            textbox_DonGia.Size = new Size(100, 23);
            textbox_DonGia.TabIndex = 6;
            // 
            // textbox_TenDienThoai
            // 
            textbox_TenDienThoai.Location = new Point(146, 104);
            textbox_TenDienThoai.Name = "textbox_TenDienThoai";
            textbox_TenDienThoai.Size = new Size(100, 23);
            textbox_TenDienThoai.TabIndex = 5;
            // 
            // textbox_DonViTinh
            // 
            textbox_DonViTinh.Location = new Point(146, 63);
            textbox_DonViTinh.Name = "textbox_DonViTinh";
            textbox_DonViTinh.ReadOnly = true;
            textbox_DonViTinh.Size = new Size(100, 23);
            textbox_DonViTinh.TabIndex = 4;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(dataGridView_SanPham);
            groupBox1.Location = new Point(335, 23);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(351, 377);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // dataGridView_SanPham
            // 
            dataGridView_SanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_SanPham.Location = new Point(16, 22);
            dataGridView_SanPham.Name = "dataGridView_SanPham";
            dataGridView_SanPham.RowTemplate.Height = 25;
            dataGridView_SanPham.Size = new Size(317, 342);
            dataGridView_SanPham.TabIndex = 0;
            dataGridView_SanPham.CellContentClick += dataGridView_SanPham_CellContentClick;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // ThongTinSanPham
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(706, 421);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "ThongTinSanPham";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Thông tin sản phẩm";
            Load += ThongTinSanPham_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView_SanPham).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button_Khoitao;
        private Button button_Xoa;
        private Button button_Sua;
        private Button button_Them;
        private Label label6;
        private Label label5;
        private Label label4;
        private TextBox textbox_SoLuong;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private DataGridView dataGridView_SanPham;
        private TextBox textbox_DonGia;
        private TextBox textbox_TenDienThoai;
        private TextBox textbox_DonViTinh;
        private DateTimePicker dateTimePicker_NgayCapNhat;
        private TextBox textBox_MaSP;
        private Label label7;
        private TextBox textbox_HinhMinhHoa;
        private ImageList imageList1;
    }
}