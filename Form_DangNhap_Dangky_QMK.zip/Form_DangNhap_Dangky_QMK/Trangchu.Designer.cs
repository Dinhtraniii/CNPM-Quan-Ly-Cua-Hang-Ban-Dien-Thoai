﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class Trangchu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Trangchu));
            label1 = new Label();
            iconlist = new ImageList(components);
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ImageAlign = ContentAlignment.MiddleLeft;
            label1.ImageIndex = 3;
            label1.ImageList = iconlist;
            label1.Location = new Point(11, 133);
            label1.Name = "label1";
            label1.Size = new Size(242, 30);
            label1.TabIndex = 0;
            label1.Text = "    Quản lý thương hiệu";
            // 
            // iconlist
            // 
            iconlist.ColorDepth = ColorDepth.Depth24Bit;
            iconlist.ImageStream = (ImageListStreamer)resources.GetObject("iconlist.ImageStream");
            iconlist.TransparentColor = Color.Transparent;
            iconlist.Images.SetKeyName(0, "admin.png");
            iconlist.Images.SetKeyName(1, "bill.png");
            iconlist.Images.SetKeyName(2, "box.png");
            iconlist.Images.SetKeyName(3, "brand-image.png");
            iconlist.Images.SetKeyName(4, "customer-review.png");
            iconlist.Images.SetKeyName(5, "home.png");
            iconlist.Images.SetKeyName(6, "list.png");
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(24, 166);
            label2.Name = "label2";
            label2.Size = new Size(214, 25);
            label2.TabIndex = 1;
            label2.Text = "Trang dành cho quản lý.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ImageAlign = ContentAlignment.MiddleLeft;
            label3.ImageIndex = 6;
            label3.ImageList = iconlist;
            label3.Location = new Point(10, 230);
            label3.Name = "label3";
            label3.Size = new Size(288, 30);
            label3.TabIndex = 2;
            label3.Text = "    Quản lý chi tiết đơn hàng";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ImageAlign = ContentAlignment.MiddleLeft;
            label4.ImageIndex = 4;
            label4.ImageList = iconlist;
            label4.Location = new Point(10, 332);
            label4.Name = "label4";
            label4.Size = new Size(234, 30);
            label4.TabIndex = 3;
            label4.Text = "    Quản lý khách hàng";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.White;
            label5.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ImageAlign = ContentAlignment.MiddleLeft;
            label5.ImageIndex = 0;
            label5.ImageList = iconlist;
            label5.Location = new Point(409, 332);
            label5.Name = "label5";
            label5.Size = new Size(185, 30);
            label5.TabIndex = 6;
            label5.Text = "    Quản lý Admin";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.White;
            label6.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ImageAlign = ContentAlignment.MiddleLeft;
            label6.ImageIndex = 1;
            label6.ImageList = iconlist;
            label6.Location = new Point(409, 230);
            label6.Name = "label6";
            label6.Size = new Size(214, 30);
            label6.TabIndex = 5;
            label6.Text = "    Quản lý đơn hàng";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.White;
            label7.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ImageAlign = ContentAlignment.MiddleLeft;
            label7.ImageIndex = 2;
            label7.ImageList = iconlist;
            label7.Location = new Point(409, 133);
            label7.Name = "label7";
            label7.Size = new Size(214, 30);
            label7.TabIndex = 4;
            label7.Text = "    Quản lý sản phẩm";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.White;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(23, 266);
            label8.Name = "label8";
            label8.Size = new Size(322, 25);
            label8.TabIndex = 7;
            label8.Text = "Trang dành cho quản lý thương hiệu.";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.White;
            label9.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(23, 370);
            label9.Name = "label9";
            label9.Size = new Size(362, 25);
            label9.TabIndex = 8;
            label9.Text = "Trang dành cho quản lý chi tiết đơn hàng.";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(429, 166);
            label10.Name = "label10";
            label10.Size = new Size(301, 25);
            label10.TabIndex = 9;
            label10.Text = "Trang dành cho quản lý sản phẩm.";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.White;
            label11.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(428, 266);
            label11.Name = "label11";
            label11.Size = new Size(300, 25);
            label11.TabIndex = 10;
            label11.Text = "Trang dành cho quản lý đơn hàng.";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.White;
            label12.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(428, 370);
            label12.Name = "label12";
            label12.Size = new Size(274, 25);
            label12.TabIndex = 11;
            label12.Text = "Trang dành cho quản lý Admin.";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.White;
            label13.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = SystemColors.MenuHighlight;
            label13.ImageList = iconlist;
            label13.Location = new Point(236, 47);
            label13.Name = "label13";
            label13.Size = new Size(227, 32);
            label13.TabIndex = 12;
            label13.Text = "ADMIN - QUẢN LÝ";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.White;
            label14.Font = new Font("Segoe UI Light", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(302, 460);
            label14.Name = "label14";
            label14.Size = new Size(123, 20);
            label14.TabIndex = 13;
            label14.Text = "FPT FORM VER 1.0";
            // 
            // Trangchu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(730, 500);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Trangchu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Trangchu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private ImageList iconlist;
        private Label label14;
    }
}