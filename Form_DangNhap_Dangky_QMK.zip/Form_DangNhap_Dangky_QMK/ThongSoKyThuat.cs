﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class ThongSoKyThuat : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select MaSP, TenSP, ManHinh, HeDieuHanh, CameraSau, CameraTruoc, CPU, RAM, BoNhoTrong, DungLuongPin, Sac From SANPHAM\r\n";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_TSSanPham.DataSource = table;
        }
        public ThongSoKyThuat()
        {
            InitializeComponent();
        }

        private void dataGridView_TTSanPham_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_TSSanPham.CurrentRow.Index;
            textBox_MaSP.Text = dataGridView_TSSanPham.Rows[i].Cells[0].Value.ToString();
            textbox_TenDienThoai.Text = dataGridView_TSSanPham.Rows[i].Cells[1].Value.ToString();
            textbox_ManHinh.Text = dataGridView_TSSanPham.Rows[i].Cells[2].Value.ToString();
            textbox_HeDieuHanh.Text = dataGridView_TSSanPham.Rows[i].Cells[3].Value.ToString();
            textbox_CameraSau.Text = dataGridView_TSSanPham.Rows[i].Cells[4].Value.ToString();
            textbox_CameraTruoc.Text = dataGridView_TSSanPham.Rows[i].Cells[5].Value.ToString();
            textbox_CPU.Text = dataGridView_TSSanPham.Rows[i].Cells[6].Value.ToString();
            combobox_RAM.Text = dataGridView_TSSanPham.Rows[i].Cells[7].Value.ToString();
            combobox_BoNhoTrong.Text = dataGridView_TSSanPham.Rows[i].Cells[8].Value.ToString();
            textbox_DungLuongPin.Text = dataGridView_TSSanPham.Rows[i].Cells[9].Value.ToString();
            textbox_Sac.Text = dataGridView_TSSanPham.Rows[i].Cells[10].Value.ToString();
        }

        private void ThongSoKyThuat_Load(object sender, EventArgs e)
        {
            sqlConnection.Open();
            loaddata();
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            if (textbox_TenDienThoai.Text == "" || textbox_ManHinh.Text == "" || textbox_HeDieuHanh.Text == "" || textbox_CameraSau.Text == "" || textbox_CameraTruoc.Text == ""
                || textbox_CPU.Text == "" || combobox_RAM.Text == "" || combobox_BoNhoTrong.Text == "" || textbox_DungLuongPin.Text == "" || textbox_Sac.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update SANPHAM set ManHinh= '" + textbox_ManHinh.Text + "', HeDieuHanh = '" + textbox_HeDieuHanh.Text + "', CameraSau = '" + textbox_CameraSau.Text + "', CameraTruoc = '" + textbox_CameraTruoc.Text + "', CPU = '" + textbox_CPU.Text + "', RAM = '" + combobox_RAM.Text + "', BoNhoTrong = '" + combobox_BoNhoTrong.Text + "', DungLuongPin = '" + textbox_DungLuongPin.Text + "', Sac = '" + textbox_Sac.Text + "'  where MaSP = '" + textBox_MaSP.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textBox_MaSP.Text = null;
            textbox_TenDienThoai.Text = null;
            textbox_ManHinh.Text = null;
            textbox_HeDieuHanh.Text = null;
            textbox_CameraSau.Clear();
            textbox_CameraTruoc.Clear();
            textbox_CPU.Clear();
            combobox_RAM.ResetText();
            combobox_BoNhoTrong.ResetText();
            textbox_DungLuongPin.Clear();
            textbox_Sac.Clear();
        }
    }
}
