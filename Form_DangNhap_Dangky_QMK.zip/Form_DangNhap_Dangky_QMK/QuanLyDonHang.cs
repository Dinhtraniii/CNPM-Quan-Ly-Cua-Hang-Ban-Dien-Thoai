﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class QuanLyDonHang : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select sodh, makh, ngayDH, trigia, ngaygiaohang, tennguoinhan, diachinhan, dienthoainhan,htthanhtoan,htgiaohang from Dondathang";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_QLDonHang.DataSource = table;
        }
        public QuanLyDonHang()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        private void LoadComboBox()
        {
            comboBox_DaThanhToan.Items.Clear();
            List<PhanLoai> phanLoais = new List<PhanLoai>()
            {
                new PhanLoai() { LoaiTT = "True", TinhTrangTT = "Đã thanh toán" },
                new PhanLoai() { LoaiTT = "False", TinhTrangTT = "Chưa thanh toán" },
            };
            comboBox_DaThanhToan.DataSource = phanLoais;
            comboBox_DaThanhToan.DisplayMember = "TinhTrangTT";
            comboBox_DaThanhToan.ValueMember = "LoaiTT";
            comboBox_DaGiaoHang.Items.Clear();
            List<PhanLoai> phanLoais1 = new List<PhanLoai>()
            {
                new PhanLoai() { LoaiGH = "True", TinhTrangGH = "Đã giao hàng" },
                new PhanLoai() { LoaiGH = "False", TinhTrangGH = "Chưa giao hàng" },
            };
            comboBox_DaGiaoHang.DataSource = phanLoais1;
            comboBox_DaGiaoHang.DisplayMember = "TinhTrangGH";
            comboBox_DaGiaoHang.ValueMember = "LoaiGH";
        }
        private void dataGridView_QLDonHang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_QLDonHang.CurrentRow.Index;
            textBox_SoDH.Text = dataGridView_QLDonHang.Rows[i].Cells[0].Value.ToString();
            textbox_MaKH.Text = dataGridView_QLDonHang.Rows[i].Cells[1].Value.ToString();
            dateTimePicker_NgayDatHang.Text = dataGridView_QLDonHang.Rows[i].Cells[2].Value.ToString();
            textbox_TriGia.Text = dataGridView_QLDonHang.Rows[i].Cells[3].Value.ToString();
            dateTimePicker_NgayGiaoHang.Text = dataGridView_QLDonHang.Rows[i].Cells[4].Value.ToString();
            textBox_TenNguoiNhan.Text = dataGridView_QLDonHang.Rows[i].Cells[5].Value.ToString();
            textbox_DiaChiNhan.Text = dataGridView_QLDonHang.Rows[i].Cells[6].Value.ToString();
            textbox_DienThoaiNhan.Text = dataGridView_QLDonHang.Rows[i].Cells[7].Value.ToString();
            comboBox_DaThanhToan.Text = dataGridView_QLDonHang.Rows[i].Cells[8].Value.ToString();
            comboBox_DaGiaoHang.Text = dataGridView_QLDonHang.Rows[i].Cells[9].Value.ToString();
        }

        private void QuanLyDonHang_Load(object sender, EventArgs e)
        {
            LoadComboBox();
            sqlConnection.Open();
            loaddata();
        }

        private void button_Them_Click(object sender, EventArgs e)
        {
            string htThanhToan = comboBox_DaThanhToan.SelectedValue.ToString();
            string htGiaoHang = comboBox_DaGiaoHang.SelectedValue.ToString();
            if (textbox_MaKH.Text == "" || dateTimePicker_NgayDatHang.Text == "" || textbox_TriGia.Text == "" || dateTimePicker_NgayGiaoHang.Text == "" || textBox_TenNguoiNhan.Text == "" || textbox_DiaChiNhan.Text == "" || textbox_DienThoaiNhan.Text == "" || comboBox_DaThanhToan.Text == "" || comboBox_DaGiaoHang.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "insert into DONDATHANG(makh, ngayDH, trigia, ngaygiaohang, tennguoinhan, diachinhan, dienthoainhan,htthanhtoan,htgiaohang) values('" + textbox_MaKH.Text + "','" + dateTimePicker_NgayDatHang.Text + "','" + textbox_TriGia.Text + "','" + dateTimePicker_NgayGiaoHang.Text + "','" + textBox_TenNguoiNhan.Text + "','" + textbox_DiaChiNhan.Text + "','" + textbox_DienThoaiNhan.Text + "','" + htThanhToan + "','" + htGiaoHang + "')";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã thêm dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            string htThanhToan = comboBox_DaThanhToan.SelectedValue.ToString();
            string htGiaoHang = comboBox_DaGiaoHang.SelectedValue.ToString();
            if (textbox_MaKH.Text == "" || dateTimePicker_NgayDatHang.Text == "" || textbox_TriGia.Text == "" || dateTimePicker_NgayGiaoHang.Text == "" || textBox_TenNguoiNhan.Text == "" || textbox_DiaChiNhan.Text == "" || textbox_DienThoaiNhan.Text == "" || comboBox_DaThanhToan.Text == "" || comboBox_DaGiaoHang.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update DONDATHANG set MaKH = '" + textbox_MaKH.Text + "', NgayDH = '" + dateTimePicker_NgayDatHang.Text + "', TriGia= '" + textbox_TriGia.Text + "', NgayGiaoHang = '" + dateTimePicker_NgayGiaoHang.Text + "', TenNguoiNhan = '" + textBox_TenNguoiNhan.Text + "', DiaChiNhan = '" + textbox_DiaChiNhan.Text + "', DienThoaiNhan = '" + textbox_DienThoaiNhan.Text + "', HTGiaoHang = '" + htGiaoHang + "', HTThanhToan = '" + htThanhToan + "'  where SoDH = '" + textBox_SoDH.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            if (textbox_MaKH.Text == "" || dateTimePicker_NgayDatHang.Text == "" || textbox_TriGia.Text == "" || dateTimePicker_NgayGiaoHang.Text == "" || textBox_TenNguoiNhan.Text == "" || textbox_DiaChiNhan.Text == "" || textbox_DienThoaiNhan.Text == "" || comboBox_DaThanhToan.Text == "" || comboBox_DaGiaoHang.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "delete from DONDATHANG where SoDH= '" + textBox_SoDH.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã xóa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textbox_DiaChiNhan.Clear();
            textbox_DienThoaiNhan.Clear();
            textbox_MaKH.Clear();
            textBox_SoDH.Clear();
            textBox_TenNguoiNhan.Clear();
            textbox_TriGia.Clear();
            comboBox_DaGiaoHang.ResetText();
            comboBox_DaThanhToan.ResetText();
            dateTimePicker_NgayDatHang.ResetText();
            dateTimePicker_NgayGiaoHang.ResetText();
        }
    }
}
