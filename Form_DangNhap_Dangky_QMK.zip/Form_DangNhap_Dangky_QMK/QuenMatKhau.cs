﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class QuenMatKhau : Form
    {
        public QuenMatKhau()
        {
            InitializeComponent();
            label1.Text = "";
        }
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        Modify modify = new Modify();
        private void button1_Click(object sender, EventArgs e)
        {
            string email = textBox2.Text;
            if (email.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập email đăng ký!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string query = "SELECT * FROM ADMIN WHERE EmailAdmin ='" + email + "'";
                command = sqlConnection.CreateCommand();
                command.CommandText = "Select MatKhauAdmin from ADMIN where EmailAdmin ='" + email + "'";
                if (modify.TaiKhoans(query).Count != 0)
                {
                    label1.ForeColor = Color.Blue;
                    sqlConnection.Open();
                    string ForgetPass = command.ExecuteScalar().ToString();
                    sqlConnection.Close();
                    label1.Text = "Mật khẩu: " + ForgetPass;
                }
                else
                {
                    label1.ForeColor = Color.Red;
                    label1.Text = "Email này chưa được đăng ký";
                }
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            DangNhap dangNhap = new DangNhap();
            dangNhap.ShowDialog();
        }
    }
}
