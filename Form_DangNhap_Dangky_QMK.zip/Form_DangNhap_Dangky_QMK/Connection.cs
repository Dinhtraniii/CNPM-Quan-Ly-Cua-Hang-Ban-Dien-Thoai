﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Form_DangNhap_Dangky_QMK
{
    internal class Connection
    {
        SqlCommand command;
        private static string stringConnection = @"Data Source=DESKTOP-P3L28LI\SQLEXPRESS;Initial Catalog=WebBanDienThoai;Integrated Security=True";
        public static SqlConnection GetSqlConnection()
        {
            return new SqlConnection(stringConnection);
        }
    }
}
