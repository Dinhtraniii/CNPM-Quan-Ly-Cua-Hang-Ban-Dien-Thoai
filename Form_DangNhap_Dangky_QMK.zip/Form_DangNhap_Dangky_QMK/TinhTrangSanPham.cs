﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Diagnostics.Metrics;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class TinhTrangSanPham : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select MaSP, TenSP, HinhMinhHoa, TenLSP , TenTinhTrang, ThongTinSanPham From SANPHAM,PHANLOAISP,TINHTRANG Where SANPHAM.MaLSP = PHANLOAISP.MaLSP and SANPHAM.MaTT = TinhTrang.MaTT";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_TTSanPham.DataSource = table;
        }
        public TinhTrangSanPham()
        {
            InitializeComponent();
        }

        private void dataGridView_TTSanPham_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_TTSanPham.CurrentRow.Index;
            textBox_MaSP.Text = dataGridView_TTSanPham.Rows[i].Cells[0].Value.ToString();
            textbox_TenDienThoai.Text = dataGridView_TTSanPham.Rows[i].Cells[1].Value.ToString();
            textbox_HinhMinhHoa.Text = dataGridView_TTSanPham.Rows[i].Cells[2].Value.ToString();
            comboBox_LoaiSanPham.Text = dataGridView_TTSanPham.Rows[i].Cells[3].Value.ToString();
            comboBox_TinhTrang.Text = dataGridView_TTSanPham.Rows[i].Cells[4].Value.ToString();
            textbox_ThongTin.Text = dataGridView_TTSanPham.Rows[i].Cells[5].Value.ToString();
        }

        private void TinhTrangSanPham_Load(object sender, EventArgs e)
        {
            LoadComboBox();
            sqlConnection.Open();
            loaddata();
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            string maLSP = comboBox_LoaiSanPham.SelectedValue.ToString();
            string maTT = comboBox_TinhTrang.SelectedValue.ToString();
            if (textbox_TenDienThoai.Text == "" || textbox_HinhMinhHoa.Text == "" || comboBox_LoaiSanPham.Text == "" || comboBox_TinhTrang.Text == "" || textbox_ThongTin.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update SANPHAM set MaLSP= '" + maLSP + "', MaTT = '" + maTT + "', ThongTinSanPham = '" + textbox_ThongTin.Text + "'  where MaSP = '" + textBox_MaSP.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void LoadComboBox()
        {
            comboBox_LoaiSanPham.Items.Clear();
            List<PhanLoai> phanLoais = new List<PhanLoai>()
            {
                new PhanLoai() { MaLSP = "1", TenLSP = "Sản phẩm mới" },
                new PhanLoai() { MaLSP = "2", TenLSP = "Sản phẩm nổi bật" },
                new PhanLoai() { MaLSP = "3", TenLSP = "Sản phẩm giá rẻ" },
            };
            comboBox_LoaiSanPham.DataSource = phanLoais;
            comboBox_LoaiSanPham.DisplayMember = "TenLSP";
            comboBox_LoaiSanPham.ValueMember = "MaLSP";
            comboBox_TinhTrang.Items.Clear();
            List<PhanLoai> phanLoais1 = new List<PhanLoai>()
            {
                new PhanLoai() { MaTT = "1", TenTinhTrang = "Mới ra mắt" },
                new PhanLoai() { MaTT = "2", TenTinhTrang = "Giảm giá sốc" },
                new PhanLoai() { MaTT = "3", TenTinhTrang = "Giá rẻ Online" },
            };
            comboBox_TinhTrang.DataSource = phanLoais1;
            comboBox_TinhTrang.DisplayMember = "TenTinhTrang";
            comboBox_TinhTrang.ValueMember = "MaTT";
        }
        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textbox_DonGia = null;
            textbox_HinhMinhHoa.Clear();
            textBox_MaSP.Clear();
            textbox_TenDienThoai.Clear();
            textbox_ThongTin.Clear();
            comboBox_LoaiSanPham.ResetText();
            comboBox_TinhTrang.ResetText();
        }
    }
}
