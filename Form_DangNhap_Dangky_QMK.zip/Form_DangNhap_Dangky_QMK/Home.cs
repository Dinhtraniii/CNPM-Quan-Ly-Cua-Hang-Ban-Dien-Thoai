﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class Home : Form
    {

        public Home()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        Modify modify = new Modify();
        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn đăng xuất?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                DangNhap dangNhap = new DangNhap();
                dangNhap.ShowDialog();
            }
        }

        private void traCuuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quanlysanpham quanlysanpham = new Quanlysanpham();
            quanlysanpham.MdiParent = this;
            quanlysanpham.Show();
            label_ThayDoi.Text = "Quản lý sản phẩm";
        }

        private void cậpNhậtPhòngHọcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChiTietDonHang chiTietDonHang = new ChiTietDonHang();
            chiTietDonHang.MdiParent = this;
            chiTietDonHang.Show();
            label_ThayDoi.Text = "Chi tiết đơn hàng";
        }

        private void traCứuThiếtBịToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLyThuongHieu quanLyThuongHieu = new QuanLyThuongHieu();
            quanLyThuongHieu.MdiParent = this;
            quanLyThuongHieu.Show();
            label_ThayDoi.Text = "Quản lý thương hiệu";
        }
        int x = 170, y = 202, a = 1;
        Font HoverFont = new Font("Segoe UI", 9, FontStyle.Bold);
        Font ResetFont = new Font("Segoe UI", 9, FontStyle.Regular);

        private void label5_MouseEnter(object sender, EventArgs e)
        {
            label_QuanLySanPham.Font = HoverFont;
            label_QuanLySanPham.ForeColor = Color.Red;
        }

        private void label5_MouseLeave(object sender, EventArgs e)
        {
            label_QuanLySanPham.Font = ResetFont;
            label_QuanLySanPham.ForeColor = Color.Black;
        }

        private void label6_MouseEnter(object sender, EventArgs e)
        {
            label_QuanLyThuongHieu.Font = HoverFont;
            label_QuanLyThuongHieu.ForeColor = Color.Red;
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            label_QuanLyThuongHieu.Font = ResetFont;
            label_QuanLyThuongHieu.ForeColor = Color.Black;
        }

        private void label_XemThietBi_MouseEnter(object sender, EventArgs e)
        {
            label_ChiTietDonHang.Font = HoverFont;
            label_ChiTietDonHang.ForeColor = Color.Red;
        }

        private void label_XemThietBi_MouseLeave(object sender, EventArgs e)
        {
            label_ChiTietDonHang.Font = ResetFont;
            label_ChiTietDonHang.ForeColor = Color.Black;
        }
        Random random = new Random();
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                x += a;
                label_ChayChu.Location = new Point(x, y);
                if (x >= 640)
                {
                    a = -1;
                    label_ChayChu.ForeColor = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));
                }
                if (x <= 167)
                {
                    a = 1;
                    label_ChayChu.ForeColor = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));
                }
            }
            catch (Exception ex)
            { }
        }

        private void thôngTinSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThongTinSanPham thongTinSanPham = new ThongTinSanPham();
            thongTinSanPham.Show();
        }

        private void tìnhTrạngSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TinhTrangSanPham tinhTrangSanPham = new TinhTrangSanPham();
            tinhTrangSanPham.Show();
        }

        private void thôngSốKỹThuậtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThongSoKyThuat thongSoKyThuat = new ThongSoKyThuat();
            thongSoKyThuat.Show();
        }

        private void quảnLýKháchHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLyKhachHang quanLyKhachHang = new QuanLyKhachHang();
            quanLyKhachHang.MdiParent = this;
            quanLyKhachHang.Show();
            label_ThayDoi.Text = "Quản lý khách hàng";
        }

        private void pictureBox6_MouseEnter(object sender, EventArgs e)
        {
            label_QuanLyKhachHang.Font = HoverFont;
            label_QuanLyKhachHang.ForeColor = Color.Red;
        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {
            label_QuanLyKhachHang.Font = ResetFont;
            label_QuanLyKhachHang.ForeColor = Color.Black;
        }

        private void label_QuanLyKhachHang_MouseEnter(object sender, EventArgs e)
        {
            label_QuanLyKhachHang.Font = HoverFont;
            label_QuanLyKhachHang.ForeColor = Color.Red;
        }

        private void label_QuanLyKhachHang_MouseLeave(object sender, EventArgs e)
        {
            label_QuanLyKhachHang.Font = ResetFont;
            label_QuanLyKhachHang.ForeColor = Color.Black;
        }


        private void pictureBox7_MouseEnter(object sender, EventArgs e)
        {
            label_QuanLyDonHang.Font = HoverFont;
            label_QuanLyDonHang.ForeColor = Color.Red;
        }

        private void pictureBox7_MouseLeave(object sender, EventArgs e)
        {
            label_QuanLyDonHang.Font = ResetFont;
            label_QuanLyDonHang.ForeColor = Color.Black;
        }

        private void quảnLýĐơnHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLyDonHang quanLyDonHang = new QuanLyDonHang();
            quanLyDonHang.MdiParent = this;
            quanLyDonHang.Show();
            label_ThayDoi.Text = "Quản lý đơn hàng";
        }

        private void pictureBox8_MouseEnter(object sender, EventArgs e)
        {
            label_QuanLyAdmin.Font = HoverFont;
            label_QuanLyAdmin.ForeColor = Color.Red;
        }

        private void pictureBox8_MouseLeave(object sender, EventArgs e)
        {
            label_QuanLyAdmin.Font = ResetFont;
            label_QuanLyAdmin.ForeColor = Color.Black;
        }

        private void quảnLýAdminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLyAdmin quanLyAdmin = new QuanLyAdmin();
            quanLyAdmin.MdiParent = this;
            quanLyAdmin.Show();
            label_ThayDoi.Text = "Quản lý Admin";
        }

        private void flowLayoutPanel7_Click(object sender, EventArgs e)
        {
            label_ThayDoi.Text = "Trang chủ Admin / Quản lý";
            Trangchu trangchu = new Trangchu();
            trangchu.MdiParent = this;
            trangchu.Show();
        }

        private void flowLayoutPanel8_Click(object sender, EventArgs e)
        {
            Quanlysanpham quanlysanpham = new Quanlysanpham();
            quanlysanpham.MdiParent = this;
            quanlysanpham.Show();
            label_ThayDoi.Text = "Quản lý sản phẩm";
        }

        private void flowLayoutPanel10_Click(object sender, EventArgs e)
        {
            QuanLyThuongHieu quanLyThuongHieu = new QuanLyThuongHieu();
            quanLyThuongHieu.MdiParent = this;
            quanLyThuongHieu.Show();
            label_ThayDoi.Text = "Quản lý thương hiệu";
        }

        private void label_ChiTietDonHang_Click(object sender, EventArgs e)
        {
            ChiTietDonHang xemThietBi = new ChiTietDonHang();
            xemThietBi.MdiParent = this;
            xemThietBi.Show();
            label_ThayDoi.Text = "Chi tiết đơn hàng";
        }

        private void label_QuanLyKhachHang_Click(object sender, EventArgs e)
        {
            QuanLyKhachHang quanLyKhachHang = new QuanLyKhachHang();
            quanLyKhachHang.MdiParent = this;
            quanLyKhachHang.Show();
            label_ThayDoi.Text = "Quản lý khách hàng";
        }

        private void label_QuanLyDonHang_Click(object sender, EventArgs e)
        {
            QuanLyDonHang quanLyDonHang = new QuanLyDonHang();
            quanLyDonHang.MdiParent = this;
            quanLyDonHang.Show();
            label_ThayDoi.Text = "Quản lý đơn hàng";
        }

        private void flowLayoutPanel16_Click(object sender, EventArgs e)
        {
            QuanLyAdmin quanLyAdmin = new QuanLyAdmin();
            quanLyAdmin.MdiParent = this;
            quanLyAdmin.Show();
            label_ThayDoi.Text = "Quản lý Admin";
        }

        private void Home_Load(object sender, EventArgs e)
        {
            label_ThayDoi.Text = "Trang chủ Admin / Quản lý";
            Trangchu trangchu = new Trangchu();
            trangchu.MdiParent = this;
            trangchu.Show();
        }

        private void flowLayoutPanel7_MouseEnter(object sender, EventArgs e)
        {
            label_TrangChus.Font = HoverFont;
            label_TrangChus.ForeColor = Color.Red;
        }

        private void flowLayoutPanel7_MouseLeave(object sender, EventArgs e)
        {
            label_TrangChus.Font = ResetFont;
            label_TrangChus.ForeColor = Color.Black;
        }
    }
}
