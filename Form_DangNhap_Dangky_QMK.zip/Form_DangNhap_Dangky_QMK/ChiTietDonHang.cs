﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class ChiTietDonHang : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select * from CTDATHANG";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_ChiTietDonHang.DataSource = table;
            dataGridView_ChiTietDonHang.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }
        public ChiTietDonHang()
        {
            InitializeComponent();
        }

        private void ChiTietDonHang_Load(object sender, EventArgs e)
        {
            sqlConnection.Open();
            loaddata();
        }
    }
}
