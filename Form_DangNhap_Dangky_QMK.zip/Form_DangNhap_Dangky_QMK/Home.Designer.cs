﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            menuStrip1 = new MenuStrip();
            toolStripMenuItem1 = new ToolStripMenuItem();
            đăngXuấtToolStripMenuItem = new ToolStripMenuItem();
            closeToolStripMenuItem = new ToolStripMenuItem();
            tiệnÍchToolStripMenuItem = new ToolStripMenuItem();
            QuanLySanPhamToolStripMenuItem = new ToolStripMenuItem();
            thôngTinSảnPhẩmToolStripMenuItem = new ToolStripMenuItem();
            tìnhTrạngSảnPhẩmToolStripMenuItem = new ToolStripMenuItem();
            thôngSốKỹThuậtToolStripMenuItem = new ToolStripMenuItem();
            QuanLyThuongHieuToolStripMenuItem = new ToolStripMenuItem();
            ChiTietDonHangToolStripMenuItem = new ToolStripMenuItem();
            quảnLýKháchHàngToolStripMenuItem = new ToolStripMenuItem();
            quảnLýĐơnHàngToolStripMenuItem = new ToolStripMenuItem();
            quảnLýAdminToolStripMenuItem = new ToolStripMenuItem();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            flowLayoutPanel5 = new FlowLayoutPanel();
            label2 = new Label();
            dateTimePicker1 = new DateTimePicker();
            flowLayoutPanel4 = new FlowLayoutPanel();
            label1 = new Label();
            dateTimePicker2 = new DateTimePicker();
            flowLayoutPanel13 = new FlowLayoutPanel();
            label10 = new Label();
            dateTimePicker3 = new DateTimePicker();
            flowLayoutPanel6 = new FlowLayoutPanel();
            label3 = new Label();
            iconlist = new ImageList(components);
            flowLayoutPanel7 = new FlowLayoutPanel();
            pictureBox2 = new PictureBox();
            label_TrangChus = new Label();
            flowLayoutPanel8 = new FlowLayoutPanel();
            pictureBox3 = new PictureBox();
            label_QuanLySanPham = new Label();
            flowLayoutPanel10 = new FlowLayoutPanel();
            pictureBox4 = new PictureBox();
            label_QuanLyThuongHieu = new Label();
            flowLayoutPanel9 = new FlowLayoutPanel();
            pictureBox5 = new PictureBox();
            label_ChiTietDonHang = new Label();
            flowLayoutPanel11 = new FlowLayoutPanel();
            pictureBox6 = new PictureBox();
            label_QuanLyKhachHang = new Label();
            flowLayoutPanel15 = new FlowLayoutPanel();
            pictureBox7 = new PictureBox();
            label_QuanLyDonHang = new Label();
            flowLayoutPanel16 = new FlowLayoutPanel();
            pictureBox8 = new PictureBox();
            label_QuanLyAdmin = new Label();
            flowLayoutPanel2 = new FlowLayoutPanel();
            flowLayoutPanel12 = new FlowLayoutPanel();
            label_ThayDoi = new Label();
            label_ChayChu = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            menuStrip1.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            flowLayoutPanel5.SuspendLayout();
            flowLayoutPanel4.SuspendLayout();
            flowLayoutPanel13.SuspendLayout();
            flowLayoutPanel6.SuspendLayout();
            flowLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            flowLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            flowLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            flowLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            flowLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            flowLayoutPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            flowLayoutPanel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            flowLayoutPanel12.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { toolStripMenuItem1, tiệnÍchToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1030, 24);
            menuStrip1.TabIndex = 8;
            menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { đăngXuấtToolStripMenuItem, closeToolStripMenuItem });
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(69, 20);
            toolStripMenuItem1.Text = "Hệ thống";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            đăngXuấtToolStripMenuItem.Size = new Size(158, 22);
            đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
            // 
            // closeToolStripMenuItem
            // 
            closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            closeToolStripMenuItem.Size = new Size(158, 22);
            closeToolStripMenuItem.Text = "Đóng ứng dụng";
            closeToolStripMenuItem.Click += closeToolStripMenuItem_Click;
            // 
            // tiệnÍchToolStripMenuItem
            // 
            tiệnÍchToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { QuanLySanPhamToolStripMenuItem, QuanLyThuongHieuToolStripMenuItem, ChiTietDonHangToolStripMenuItem, quảnLýKháchHàngToolStripMenuItem, quảnLýĐơnHàngToolStripMenuItem, quảnLýAdminToolStripMenuItem });
            tiệnÍchToolStripMenuItem.Name = "tiệnÍchToolStripMenuItem";
            tiệnÍchToolStripMenuItem.Size = new Size(60, 20);
            tiệnÍchToolStripMenuItem.Text = "Tiện ích";
            // 
            // QuanLySanPhamToolStripMenuItem
            // 
            QuanLySanPhamToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thôngTinSảnPhẩmToolStripMenuItem, tìnhTrạngSảnPhẩmToolStripMenuItem, thôngSốKỹThuậtToolStripMenuItem });
            QuanLySanPhamToolStripMenuItem.Name = "QuanLySanPhamToolStripMenuItem";
            QuanLySanPhamToolStripMenuItem.Size = new Size(183, 22);
            QuanLySanPhamToolStripMenuItem.Text = "Quản lý sản phẩm";
            QuanLySanPhamToolStripMenuItem.Click += traCuuToolStripMenuItem_Click;
            // 
            // thôngTinSảnPhẩmToolStripMenuItem
            // 
            thôngTinSảnPhẩmToolStripMenuItem.Name = "thôngTinSảnPhẩmToolStripMenuItem";
            thôngTinSảnPhẩmToolStripMenuItem.Size = new Size(183, 22);
            thôngTinSảnPhẩmToolStripMenuItem.Text = "Thông tin sản phẩm";
            thôngTinSảnPhẩmToolStripMenuItem.Click += thôngTinSảnPhẩmToolStripMenuItem_Click;
            // 
            // tìnhTrạngSảnPhẩmToolStripMenuItem
            // 
            tìnhTrạngSảnPhẩmToolStripMenuItem.Name = "tìnhTrạngSảnPhẩmToolStripMenuItem";
            tìnhTrạngSảnPhẩmToolStripMenuItem.Size = new Size(183, 22);
            tìnhTrạngSảnPhẩmToolStripMenuItem.Text = "Tình trạng sản phẩm";
            tìnhTrạngSảnPhẩmToolStripMenuItem.Click += tìnhTrạngSảnPhẩmToolStripMenuItem_Click;
            // 
            // thôngSốKỹThuậtToolStripMenuItem
            // 
            thôngSốKỹThuậtToolStripMenuItem.Name = "thôngSốKỹThuậtToolStripMenuItem";
            thôngSốKỹThuậtToolStripMenuItem.Size = new Size(183, 22);
            thôngSốKỹThuậtToolStripMenuItem.Text = "Thông số kỹ thuật";
            thôngSốKỹThuậtToolStripMenuItem.Click += thôngSốKỹThuậtToolStripMenuItem_Click;
            // 
            // QuanLyThuongHieuToolStripMenuItem
            // 
            QuanLyThuongHieuToolStripMenuItem.Name = "QuanLyThuongHieuToolStripMenuItem";
            QuanLyThuongHieuToolStripMenuItem.Size = new Size(183, 22);
            QuanLyThuongHieuToolStripMenuItem.Text = "Quản lý thương hiệu";
            QuanLyThuongHieuToolStripMenuItem.Click += traCứuThiếtBịToolStripMenuItem_Click;
            // 
            // ChiTietDonHangToolStripMenuItem
            // 
            ChiTietDonHangToolStripMenuItem.Name = "ChiTietDonHangToolStripMenuItem";
            ChiTietDonHangToolStripMenuItem.Size = new Size(183, 22);
            ChiTietDonHangToolStripMenuItem.Text = "Chi tiết đơn hàng";
            ChiTietDonHangToolStripMenuItem.Click += cậpNhậtPhòngHọcToolStripMenuItem_Click;
            // 
            // quảnLýKháchHàngToolStripMenuItem
            // 
            quảnLýKháchHàngToolStripMenuItem.Name = "quảnLýKháchHàngToolStripMenuItem";
            quảnLýKháchHàngToolStripMenuItem.Size = new Size(183, 22);
            quảnLýKháchHàngToolStripMenuItem.Text = "Quản lý khách hàng";
            quảnLýKháchHàngToolStripMenuItem.Click += quảnLýKháchHàngToolStripMenuItem_Click;
            // 
            // quảnLýĐơnHàngToolStripMenuItem
            // 
            quảnLýĐơnHàngToolStripMenuItem.Name = "quảnLýĐơnHàngToolStripMenuItem";
            quảnLýĐơnHàngToolStripMenuItem.Size = new Size(183, 22);
            quảnLýĐơnHàngToolStripMenuItem.Text = "Quản lý đơn hàng";
            quảnLýĐơnHàngToolStripMenuItem.Click += quảnLýĐơnHàngToolStripMenuItem_Click;
            // 
            // quảnLýAdminToolStripMenuItem
            // 
            quảnLýAdminToolStripMenuItem.Name = "quảnLýAdminToolStripMenuItem";
            quảnLýAdminToolStripMenuItem.Size = new Size(183, 22);
            quảnLýAdminToolStripMenuItem.Text = "Quản lý Admin";
            quảnLýAdminToolStripMenuItem.Click += quảnLýAdminToolStripMenuItem_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel1.Controls.Add(flowLayoutPanel3);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel6);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel7);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel8);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel10);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel9);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel11);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel15);
            flowLayoutPanel1.Controls.Add(flowLayoutPanel16);
            flowLayoutPanel1.Dock = DockStyle.Left;
            flowLayoutPanel1.Location = new Point(0, 24);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(166, 688);
            flowLayoutPanel1.TabIndex = 10;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel3.Controls.Add(label6);
            flowLayoutPanel3.Controls.Add(pictureBox1);
            flowLayoutPanel3.Controls.Add(flowLayoutPanel5);
            flowLayoutPanel3.Controls.Add(flowLayoutPanel13);
            flowLayoutPanel3.ImeMode = ImeMode.On;
            flowLayoutPanel3.Location = new Point(3, 3);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(158, 131);
            flowLayoutPanel3.TabIndex = 0;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(3, 0);
            label6.Name = "label6";
            label6.Size = new Size(0, 15);
            label6.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(51, 3);
            pictureBox1.Margin = new Padding(45, 3, 3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(58, 53);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // flowLayoutPanel5
            // 
            flowLayoutPanel5.Controls.Add(label2);
            flowLayoutPanel5.Controls.Add(dateTimePicker1);
            flowLayoutPanel5.Controls.Add(flowLayoutPanel4);
            flowLayoutPanel5.Location = new Point(3, 66);
            flowLayoutPanel5.Margin = new Padding(3, 7, 3, 3);
            flowLayoutPanel5.Name = "flowLayoutPanel5";
            flowLayoutPanel5.Size = new Size(147, 26);
            flowLayoutPanel5.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(3, 7);
            label2.Margin = new Padding(3, 7, 10, 10);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 0;
            label2.Text = "NGÀY:";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Location = new Point(54, 3);
            dateTimePicker1.Margin = new Padding(0, 3, 3, 3);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(86, 23);
            dateTimePicker1.TabIndex = 15;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Controls.Add(label1);
            flowLayoutPanel4.Controls.Add(dateTimePicker2);
            flowLayoutPanel4.Location = new Point(3, 39);
            flowLayoutPanel4.Margin = new Padding(3, 7, 3, 3);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(158, 34);
            flowLayoutPanel4.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 7);
            label1.Margin = new Padding(3, 7, 10, 10);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 0;
            label1.Text = "TODAY:";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Format = DateTimePickerFormat.Short;
            dateTimePicker2.Location = new Point(59, 3);
            dateTimePicker2.Margin = new Padding(0, 3, 3, 3);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(81, 23);
            dateTimePicker2.TabIndex = 15;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Controls.Add(label10);
            flowLayoutPanel13.Controls.Add(dateTimePicker3);
            flowLayoutPanel13.Location = new Point(3, 98);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(147, 29);
            flowLayoutPanel13.TabIndex = 3;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(3, 7);
            label10.Margin = new Padding(3, 7, 10, 10);
            label10.Name = "label10";
            label10.Size = new Size(30, 15);
            label10.TabIndex = 16;
            label10.Text = "GIỜ:";
            // 
            // dateTimePicker3
            // 
            dateTimePicker3.Format = DateTimePickerFormat.Time;
            dateTimePicker3.Location = new Point(53, 3);
            dateTimePicker3.Margin = new Padding(10, 3, 3, 3);
            dateTimePicker3.Name = "dateTimePicker3";
            dateTimePicker3.Size = new Size(87, 23);
            dateTimePicker3.TabIndex = 17;
            // 
            // flowLayoutPanel6
            // 
            flowLayoutPanel6.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel6.Controls.Add(label3);
            flowLayoutPanel6.Location = new Point(3, 140);
            flowLayoutPanel6.Name = "flowLayoutPanel6";
            flowLayoutPanel6.Size = new Size(158, 34);
            flowLayoutPanel6.TabIndex = 1;
            // 
            // label3
            // 
            label3.ImageAlign = ContentAlignment.MiddleLeft;
            label3.ImageIndex = 9;
            label3.ImageList = iconlist;
            label3.Location = new Point(50, 8);
            label3.Margin = new Padding(50, 8, 60, 60);
            label3.Name = "label3";
            label3.Size = new Size(59, 16);
            label3.TabIndex = 0;
            label3.Text = "      MENU";
            // 
            // iconlist
            // 
            iconlist.ColorDepth = ColorDepth.Depth8Bit;
            iconlist.ImageStream = (ImageListStreamer)resources.GetObject("iconlist.ImageStream");
            iconlist.TransparentColor = Color.Transparent;
            iconlist.Images.SetKeyName(0, "admin.png");
            iconlist.Images.SetKeyName(1, "bill.png");
            iconlist.Images.SetKeyName(2, "box.png");
            iconlist.Images.SetKeyName(3, "brand-image.png");
            iconlist.Images.SetKeyName(4, "customer-review.png");
            iconlist.Images.SetKeyName(5, "home.png");
            iconlist.Images.SetKeyName(6, "list.png");
            iconlist.Images.SetKeyName(7, "welcome-back.png");
            iconlist.Images.SetKeyName(8, "welcome-back (1).png");
            iconlist.Images.SetKeyName(9, "menu.png");
            // 
            // flowLayoutPanel7
            // 
            flowLayoutPanel7.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel7.Controls.Add(pictureBox2);
            flowLayoutPanel7.Controls.Add(label_TrangChus);
            flowLayoutPanel7.Location = new Point(3, 180);
            flowLayoutPanel7.Name = "flowLayoutPanel7";
            flowLayoutPanel7.Size = new Size(158, 63);
            flowLayoutPanel7.TabIndex = 2;
            flowLayoutPanel7.Click += flowLayoutPanel7_Click;
            flowLayoutPanel7.MouseEnter += flowLayoutPanel7_MouseEnter;
            flowLayoutPanel7.MouseLeave += flowLayoutPanel7_MouseLeave;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(7, 7);
            pictureBox2.Margin = new Padding(7, 7, 3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(52, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            pictureBox2.Click += flowLayoutPanel7_Click;
            pictureBox2.MouseEnter += flowLayoutPanel7_MouseEnter;
            pictureBox2.MouseLeave += flowLayoutPanel7_MouseLeave;
            // 
            // label_TrangChus
            // 
            label_TrangChus.AutoSize = true;
            label_TrangChus.Location = new Point(70, 25);
            label_TrangChus.Margin = new Padding(8, 25, 3, 0);
            label_TrangChus.Name = "label_TrangChus";
            label_TrangChus.Size = new Size(73, 15);
            label_TrangChus.TabIndex = 1;
            label_TrangChus.Text = "TRANG CHỦ";
            label_TrangChus.Click += flowLayoutPanel7_Click;
            label_TrangChus.MouseEnter += flowLayoutPanel7_MouseEnter;
            label_TrangChus.MouseLeave += flowLayoutPanel7_MouseLeave;
            // 
            // flowLayoutPanel8
            // 
            flowLayoutPanel8.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel8.Controls.Add(pictureBox3);
            flowLayoutPanel8.Controls.Add(label_QuanLySanPham);
            flowLayoutPanel8.Location = new Point(3, 249);
            flowLayoutPanel8.Name = "flowLayoutPanel8";
            flowLayoutPanel8.Size = new Size(158, 63);
            flowLayoutPanel8.TabIndex = 3;
            flowLayoutPanel8.Click += flowLayoutPanel8_Click;
            flowLayoutPanel8.MouseEnter += label5_MouseEnter;
            flowLayoutPanel8.MouseLeave += label5_MouseLeave;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(7, 7);
            pictureBox3.Margin = new Padding(7, 7, 3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(52, 50);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            pictureBox3.Click += flowLayoutPanel8_Click;
            pictureBox3.MouseEnter += label5_MouseEnter;
            pictureBox3.MouseLeave += label5_MouseLeave;
            // 
            // label_QuanLySanPham
            // 
            label_QuanLySanPham.Location = new Point(70, 17);
            label_QuanLySanPham.Margin = new Padding(8, 17, 3, 0);
            label_QuanLySanPham.Name = "label_QuanLySanPham";
            label_QuanLySanPham.Size = new Size(80, 32);
            label_QuanLySanPham.TabIndex = 3;
            label_QuanLySanPham.Text = "QUẢN LÝ SẢN PHẨM";
            label_QuanLySanPham.Click += flowLayoutPanel8_Click;
            label_QuanLySanPham.MouseEnter += label5_MouseEnter;
            label_QuanLySanPham.MouseLeave += label5_MouseLeave;
            // 
            // flowLayoutPanel10
            // 
            flowLayoutPanel10.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel10.Controls.Add(pictureBox4);
            flowLayoutPanel10.Controls.Add(label_QuanLyThuongHieu);
            flowLayoutPanel10.Location = new Point(3, 318);
            flowLayoutPanel10.Name = "flowLayoutPanel10";
            flowLayoutPanel10.Size = new Size(158, 66);
            flowLayoutPanel10.TabIndex = 3;
            flowLayoutPanel10.Click += flowLayoutPanel10_Click;
            flowLayoutPanel10.MouseEnter += label6_MouseEnter;
            flowLayoutPanel10.MouseLeave += label6_MouseLeave;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(7, 7);
            pictureBox4.Margin = new Padding(7, 7, 3, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(52, 50);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            pictureBox4.Click += flowLayoutPanel10_Click;
            pictureBox4.MouseEnter += label6_MouseEnter;
            pictureBox4.MouseLeave += label6_MouseLeave;
            // 
            // label_QuanLyThuongHieu
            // 
            label_QuanLyThuongHieu.Location = new Point(70, 17);
            label_QuanLyThuongHieu.Margin = new Padding(8, 17, 3, 0);
            label_QuanLyThuongHieu.Name = "label_QuanLyThuongHieu";
            label_QuanLyThuongHieu.Size = new Size(73, 32);
            label_QuanLyThuongHieu.TabIndex = 4;
            label_QuanLyThuongHieu.Text = "THƯƠNG HIỆU";
            label_QuanLyThuongHieu.Click += flowLayoutPanel10_Click;
            label_QuanLyThuongHieu.MouseEnter += label6_MouseEnter;
            label_QuanLyThuongHieu.MouseLeave += label6_MouseLeave;
            // 
            // flowLayoutPanel9
            // 
            flowLayoutPanel9.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel9.Controls.Add(pictureBox5);
            flowLayoutPanel9.Controls.Add(label_ChiTietDonHang);
            flowLayoutPanel9.Location = new Point(3, 390);
            flowLayoutPanel9.Name = "flowLayoutPanel9";
            flowLayoutPanel9.Size = new Size(158, 65);
            flowLayoutPanel9.TabIndex = 3;
            flowLayoutPanel9.Click += label_ChiTietDonHang_Click;
            flowLayoutPanel9.MouseEnter += label_XemThietBi_MouseEnter;
            flowLayoutPanel9.MouseLeave += label_XemThietBi_MouseLeave;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(7, 7);
            pictureBox5.Margin = new Padding(7, 7, 3, 3);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(52, 50);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 2;
            pictureBox5.TabStop = false;
            pictureBox5.Click += label_ChiTietDonHang_Click;
            pictureBox5.MouseEnter += label_XemThietBi_MouseEnter;
            pictureBox5.MouseLeave += label_XemThietBi_MouseLeave;
            // 
            // label_ChiTietDonHang
            // 
            label_ChiTietDonHang.Location = new Point(70, 17);
            label_ChiTietDonHang.Margin = new Padding(8, 17, 3, 0);
            label_ChiTietDonHang.Name = "label_ChiTietDonHang";
            label_ChiTietDonHang.Size = new Size(73, 32);
            label_ChiTietDonHang.TabIndex = 4;
            label_ChiTietDonHang.Text = "CHI TIẾT ĐƠN HÀNG";
            label_ChiTietDonHang.Click += label_ChiTietDonHang_Click;
            label_ChiTietDonHang.MouseEnter += label_XemThietBi_MouseEnter;
            label_ChiTietDonHang.MouseLeave += label_XemThietBi_MouseLeave;
            // 
            // flowLayoutPanel11
            // 
            flowLayoutPanel11.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel11.Controls.Add(pictureBox6);
            flowLayoutPanel11.Controls.Add(label_QuanLyKhachHang);
            flowLayoutPanel11.Location = new Point(3, 461);
            flowLayoutPanel11.Name = "flowLayoutPanel11";
            flowLayoutPanel11.Size = new Size(158, 68);
            flowLayoutPanel11.TabIndex = 3;
            flowLayoutPanel11.Click += label_QuanLyKhachHang_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(7, 7);
            pictureBox6.Margin = new Padding(7, 7, 3, 3);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(52, 50);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 2;
            pictureBox6.TabStop = false;
            pictureBox6.Click += label_QuanLyKhachHang_Click;
            pictureBox6.MouseEnter += pictureBox6_MouseEnter;
            pictureBox6.MouseLeave += pictureBox6_MouseLeave;
            // 
            // label_QuanLyKhachHang
            // 
            label_QuanLyKhachHang.Location = new Point(70, 17);
            label_QuanLyKhachHang.Margin = new Padding(8, 17, 3, 0);
            label_QuanLyKhachHang.Name = "label_QuanLyKhachHang";
            label_QuanLyKhachHang.Size = new Size(61, 32);
            label_QuanLyKhachHang.TabIndex = 4;
            label_QuanLyKhachHang.Text = "KHÁCH HÀNG";
            label_QuanLyKhachHang.Click += label_QuanLyKhachHang_Click;
            label_QuanLyKhachHang.MouseEnter += label_QuanLyKhachHang_MouseEnter;
            label_QuanLyKhachHang.MouseLeave += label_QuanLyKhachHang_MouseLeave;
            // 
            // flowLayoutPanel15
            // 
            flowLayoutPanel15.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel15.Controls.Add(pictureBox7);
            flowLayoutPanel15.Controls.Add(label_QuanLyDonHang);
            flowLayoutPanel15.Location = new Point(3, 535);
            flowLayoutPanel15.Name = "flowLayoutPanel15";
            flowLayoutPanel15.Size = new Size(158, 68);
            flowLayoutPanel15.TabIndex = 5;
            flowLayoutPanel15.Click += label_QuanLyDonHang_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(7, 7);
            pictureBox7.Margin = new Padding(7, 7, 3, 3);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(52, 50);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            pictureBox7.Click += label_QuanLyDonHang_Click;
            pictureBox7.MouseEnter += pictureBox7_MouseEnter;
            pictureBox7.MouseLeave += pictureBox7_MouseLeave;
            // 
            // label_QuanLyDonHang
            // 
            label_QuanLyDonHang.Location = new Point(70, 17);
            label_QuanLyDonHang.Margin = new Padding(8, 17, 3, 0);
            label_QuanLyDonHang.Name = "label_QuanLyDonHang";
            label_QuanLyDonHang.Size = new Size(61, 32);
            label_QuanLyDonHang.TabIndex = 4;
            label_QuanLyDonHang.Text = "ĐƠN HÀNG";
            label_QuanLyDonHang.Click += label_QuanLyDonHang_Click;
            label_QuanLyDonHang.MouseEnter += pictureBox7_MouseEnter;
            label_QuanLyDonHang.MouseLeave += pictureBox7_MouseLeave;
            // 
            // flowLayoutPanel16
            // 
            flowLayoutPanel16.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel16.Controls.Add(pictureBox8);
            flowLayoutPanel16.Controls.Add(label_QuanLyAdmin);
            flowLayoutPanel16.Location = new Point(3, 609);
            flowLayoutPanel16.Name = "flowLayoutPanel16";
            flowLayoutPanel16.Size = new Size(158, 68);
            flowLayoutPanel16.TabIndex = 5;
            flowLayoutPanel16.Click += flowLayoutPanel16_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(7, 7);
            pictureBox8.Margin = new Padding(7, 7, 3, 3);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(52, 50);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 2;
            pictureBox8.TabStop = false;
            pictureBox8.Click += flowLayoutPanel16_Click;
            pictureBox8.MouseEnter += pictureBox8_MouseEnter;
            pictureBox8.MouseLeave += pictureBox8_MouseLeave;
            // 
            // label_QuanLyAdmin
            // 
            label_QuanLyAdmin.Location = new Point(70, 17);
            label_QuanLyAdmin.Margin = new Padding(8, 17, 3, 0);
            label_QuanLyAdmin.Name = "label_QuanLyAdmin";
            label_QuanLyAdmin.Size = new Size(61, 32);
            label_QuanLyAdmin.TabIndex = 4;
            label_QuanLyAdmin.Text = "QUẢN LÝ ADMIN";
            label_QuanLyAdmin.Click += flowLayoutPanel16_Click;
            label_QuanLyAdmin.MouseEnter += pictureBox8_MouseEnter;
            label_QuanLyAdmin.MouseLeave += pictureBox8_MouseLeave;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.BackgroundImage = (Image)resources.GetObject("flowLayoutPanel2.BackgroundImage");
            flowLayoutPanel2.BackgroundImageLayout = ImageLayout.Stretch;
            flowLayoutPanel2.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel2.Dock = DockStyle.Top;
            flowLayoutPanel2.Location = new Point(166, 24);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(864, 135);
            flowLayoutPanel2.TabIndex = 11;
            // 
            // flowLayoutPanel12
            // 
            flowLayoutPanel12.BorderStyle = BorderStyle.Fixed3D;
            flowLayoutPanel12.Controls.Add(label_ThayDoi);
            flowLayoutPanel12.Dock = DockStyle.Top;
            flowLayoutPanel12.Location = new Point(166, 159);
            flowLayoutPanel12.Name = "flowLayoutPanel12";
            flowLayoutPanel12.Size = new Size(864, 40);
            flowLayoutPanel12.TabIndex = 13;
            // 
            // label_ThayDoi
            // 
            label_ThayDoi.AutoSize = true;
            label_ThayDoi.Font = new Font("Arial", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label_ThayDoi.Location = new Point(0, 2);
            label_ThayDoi.Margin = new Padding(0, 2, 3, 0);
            label_ThayDoi.Name = "label_ThayDoi";
            label_ThayDoi.Size = new Size(466, 32);
            label_ThayDoi.TabIndex = 0;
            label_ThayDoi.Text = "Quản lý bán điện thoại - FPT Shop";
            // 
            // label_ChayChu
            // 
            label_ChayChu.AutoSize = true;
            label_ChayChu.BackColor = Color.White;
            label_ChayChu.ImageAlign = ContentAlignment.MiddleLeft;
            label_ChayChu.ImageIndex = 8;
            label_ChayChu.ImageList = iconlist;
            label_ChayChu.Location = new Point(168, 202);
            label_ChayChu.Name = "label_ChayChu";
            label_ChayChu.Size = new Size(400, 15);
            label_ChayChu.TabIndex = 0;
            label_ChayChu.Text = "      CHÀO MỪNG BẠN ĐÃ ĐẾN VỚI HỆ THỐNG QUẢN LÝ BÁN ĐIỆN THOẠI";
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1;
            timer1.Tick += timer1_Tick;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoValidate = AutoValidate.EnablePreventFocusChange;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1030, 712);
            Controls.Add(label_ChayChu);
            Controls.Add(flowLayoutPanel12);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(menuStrip1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            ImeMode = ImeMode.On;
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            MaximizeBox = false;
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quản lý bán hàng điện thoại";
            Load += Home_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel3.ResumeLayout(false);
            flowLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            flowLayoutPanel5.ResumeLayout(false);
            flowLayoutPanel5.PerformLayout();
            flowLayoutPanel4.ResumeLayout(false);
            flowLayoutPanel4.PerformLayout();
            flowLayoutPanel13.ResumeLayout(false);
            flowLayoutPanel13.PerformLayout();
            flowLayoutPanel6.ResumeLayout(false);
            flowLayoutPanel7.ResumeLayout(false);
            flowLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            flowLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            flowLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            flowLayoutPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            flowLayoutPanel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            flowLayoutPanel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            flowLayoutPanel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            flowLayoutPanel12.ResumeLayout(false);
            flowLayoutPanel12.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem closeToolStripMenuItem;
        private ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private ToolStripMenuItem tiệnÍchToolStripMenuItem;
        private ToolStripMenuItem QuanLySanPhamToolStripMenuItem;
        private ToolStripMenuItem ChiTietDonHangToolStripMenuItem;
        private ToolStripMenuItem QuanLyThuongHieuToolStripMenuItem;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel2;
        private FlowLayoutPanel flowLayoutPanel3;
        private PictureBox pictureBox1;
        private FlowLayoutPanel flowLayoutPanel5;
        private Label label2;
        private FlowLayoutPanel flowLayoutPanel6;
        private Label label3;
        private FlowLayoutPanel flowLayoutPanel7;
        private FlowLayoutPanel flowLayoutPanel8;
        private FlowLayoutPanel flowLayoutPanel10;
        private FlowLayoutPanel flowLayoutPanel9;
        private FlowLayoutPanel flowLayoutPanel11;
        private PictureBox pictureBox2;
        private Label label_TrangChus;
        private PictureBox pictureBox3;
        private Label label_QuanLySanPham;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label_QuanLyThuongHieu;
        private Label label_ChiTietDonHang;
        private Label label_QuanLyKhachHang;
        private FlowLayoutPanel flowLayoutPanel12;
        private Label label_ThayDoi;
        private Label label_ChayChu;
        private System.Windows.Forms.Timer timer1;
        private DateTimePicker dateTimePicker1;
        private FlowLayoutPanel flowLayoutPanel4;
        private Label label1;
        private DateTimePicker dateTimePicker2;
        private FlowLayoutPanel flowLayoutPanel13;
        private Label label10;
        private DateTimePicker dateTimePicker3;
        private FlowLayoutPanel flowLayoutPanel15;
        private PictureBox pictureBox7;
        private Label label_QuanLyDonHang;
        private FlowLayoutPanel flowLayoutPanel16;
        private PictureBox pictureBox8;
        private Label label_QuanLyAdmin;
        private Label label6;
        private ToolStripMenuItem thôngTinSảnPhẩmToolStripMenuItem;
        private ToolStripMenuItem tìnhTrạngSảnPhẩmToolStripMenuItem;
        private ToolStripMenuItem thôngSốKỹThuậtToolStripMenuItem;
        private ToolStripMenuItem quảnLýKháchHàngToolStripMenuItem;
        private ToolStripMenuItem quảnLýĐơnHàngToolStripMenuItem;
        private ToolStripMenuItem quảnLýAdminToolStripMenuItem;
        private ImageList iconlist;
    }
}