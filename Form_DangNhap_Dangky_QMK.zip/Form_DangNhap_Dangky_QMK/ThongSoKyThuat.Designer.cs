﻿namespace Form_DangNhap_Dangky_QMK
{
    partial class ThongSoKyThuat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongSoKyThuat));
            groupBox2 = new GroupBox();
            button_Khoitao = new Button();
            imageList1 = new ImageList(components);
            textbox_Sac = new TextBox();
            button_Sua = new Button();
            label11 = new Label();
            textbox_DungLuongPin = new TextBox();
            label2 = new Label();
            textbox_CPU = new TextBox();
            label10 = new Label();
            textbox_CameraTruoc = new TextBox();
            label9 = new Label();
            textbox_CameraSau = new TextBox();
            label8 = new Label();
            textbox_HeDieuHanh = new TextBox();
            label5 = new Label();
            combobox_BoNhoTrong = new ComboBox();
            combobox_RAM = new ComboBox();
            textBox_MaSP = new TextBox();
            label7 = new Label();
            textbox_ManHinh = new TextBox();
            textbox_TenDienThoai = new TextBox();
            label6 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            dataGridView_TSSanPham = new DataGridView();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView_TSSanPham).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.White;
            groupBox2.Controls.Add(button_Khoitao);
            groupBox2.Controls.Add(textbox_Sac);
            groupBox2.Controls.Add(button_Sua);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(textbox_DungLuongPin);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(textbox_CPU);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(textbox_CameraTruoc);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(textbox_CameraSau);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textbox_HeDieuHanh);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(combobox_BoNhoTrong);
            groupBox2.Controls.Add(combobox_RAM);
            groupBox2.Controls.Add(textBox_MaSP);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(textbox_ManHinh);
            groupBox2.Controls.Add(textbox_TenDienThoai);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(21, 6);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(291, 377);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin cụ thể";
            // 
            // button_Khoitao
            // 
            button_Khoitao.ImageAlign = ContentAlignment.MiddleLeft;
            button_Khoitao.ImageIndex = 0;
            button_Khoitao.ImageList = imageList1;
            button_Khoitao.Location = new Point(148, 342);
            button_Khoitao.Name = "button_Khoitao";
            button_Khoitao.Size = new Size(97, 23);
            button_Khoitao.TabIndex = 8;
            button_Khoitao.Text = "      Khởi tạo";
            button_Khoitao.UseVisualStyleBackColor = true;
            button_Khoitao.Click += button_Khoitao_Click;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-reload-50.png");
            imageList1.Images.SetKeyName(1, "icons8-delete-50.png");
            imageList1.Images.SetKeyName(2, "icons8-edit-64.png");
            imageList1.Images.SetKeyName(3, "icons8-add-30.png");
            // 
            // textbox_Sac
            // 
            textbox_Sac.Location = new Point(145, 313);
            textbox_Sac.Name = "textbox_Sac";
            textbox_Sac.Size = new Size(100, 23);
            textbox_Sac.TabIndex = 27;
            // 
            // button_Sua
            // 
            button_Sua.ImageAlign = ContentAlignment.MiddleLeft;
            button_Sua.ImageIndex = 2;
            button_Sua.ImageList = imageList1;
            button_Sua.Location = new Point(45, 341);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 23);
            button_Sua.TabIndex = 9;
            button_Sua.Text = "  Sửa";
            button_Sua.UseVisualStyleBackColor = true;
            button_Sua.Click += button_Sua_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(45, 316);
            label11.Name = "label11";
            label11.Size = new Size(28, 15);
            label11.TabIndex = 26;
            label11.Text = "Sạc:";
            // 
            // textbox_DungLuongPin
            // 
            textbox_DungLuongPin.Location = new Point(145, 284);
            textbox_DungLuongPin.Name = "textbox_DungLuongPin";
            textbox_DungLuongPin.Size = new Size(100, 23);
            textbox_DungLuongPin.TabIndex = 25;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(45, 287);
            label2.Name = "label2";
            label2.Size = new Size(93, 15);
            label2.TabIndex = 24;
            label2.Text = "Dung lượng pin:";
            // 
            // textbox_CPU
            // 
            textbox_CPU.Location = new Point(145, 196);
            textbox_CPU.Name = "textbox_CPU";
            textbox_CPU.Size = new Size(100, 23);
            textbox_CPU.TabIndex = 23;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(45, 199);
            label10.Name = "label10";
            label10.Size = new Size(33, 15);
            label10.TabIndex = 22;
            label10.Text = "CPU:";
            // 
            // textbox_CameraTruoc
            // 
            textbox_CameraTruoc.Location = new Point(145, 167);
            textbox_CameraTruoc.Name = "textbox_CameraTruoc";
            textbox_CameraTruoc.Size = new Size(100, 23);
            textbox_CameraTruoc.TabIndex = 21;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(45, 170);
            label9.Name = "label9";
            label9.Size = new Size(83, 15);
            label9.TabIndex = 20;
            label9.Text = "Camera Trước:";
            // 
            // textbox_CameraSau
            // 
            textbox_CameraSau.Location = new Point(145, 138);
            textbox_CameraSau.Name = "textbox_CameraSau";
            textbox_CameraSau.Size = new Size(100, 23);
            textbox_CameraSau.TabIndex = 19;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(45, 141);
            label8.Name = "label8";
            label8.Size = new Size(73, 15);
            label8.TabIndex = 18;
            label8.Text = "Camera Sau:";
            // 
            // textbox_HeDieuHanh
            // 
            textbox_HeDieuHanh.Location = new Point(145, 109);
            textbox_HeDieuHanh.Name = "textbox_HeDieuHanh";
            textbox_HeDieuHanh.Size = new Size(100, 23);
            textbox_HeDieuHanh.TabIndex = 17;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(45, 112);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 16;
            label5.Text = "Hệ điều hành:";
            // 
            // combobox_BoNhoTrong
            // 
            combobox_BoNhoTrong.FormattingEnabled = true;
            combobox_BoNhoTrong.Items.AddRange(new object[] { "32 GB", "64 GB", "128 GB", "256 GB" });
            combobox_BoNhoTrong.Location = new Point(145, 255);
            combobox_BoNhoTrong.Name = "combobox_BoNhoTrong";
            combobox_BoNhoTrong.Size = new Size(100, 23);
            combobox_BoNhoTrong.TabIndex = 15;
            // 
            // combobox_RAM
            // 
            combobox_RAM.FormattingEnabled = true;
            combobox_RAM.Items.AddRange(new object[] { "1 GB", "2 GB", "3 GB", "4 GB", "6 GB", "8 GB", "12 GB" });
            combobox_RAM.Location = new Point(145, 226);
            combobox_RAM.Name = "combobox_RAM";
            combobox_RAM.Size = new Size(100, 23);
            combobox_RAM.TabIndex = 14;
            // 
            // textBox_MaSP
            // 
            textBox_MaSP.Location = new Point(145, 22);
            textBox_MaSP.Name = "textBox_MaSP";
            textBox_MaSP.ReadOnly = true;
            textBox_MaSP.Size = new Size(100, 23);
            textBox_MaSP.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(45, 25);
            label7.Name = "label7";
            label7.Size = new Size(82, 15);
            label7.TabIndex = 9;
            label7.Text = "Mã sản phẩm:";
            // 
            // textbox_ManHinh
            // 
            textbox_ManHinh.Location = new Point(145, 80);
            textbox_ManHinh.Name = "textbox_ManHinh";
            textbox_ManHinh.Size = new Size(100, 23);
            textbox_ManHinh.TabIndex = 7;
            // 
            // textbox_TenDienThoai
            // 
            textbox_TenDienThoai.Location = new Point(145, 51);
            textbox_TenDienThoai.Name = "textbox_TenDienThoai";
            textbox_TenDienThoai.ReadOnly = true;
            textbox_TenDienThoai.Size = new Size(100, 23);
            textbox_TenDienThoai.TabIndex = 5;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(45, 54);
            label6.Name = "label6";
            label6.Size = new Size(84, 15);
            label6.TabIndex = 0;
            label6.Text = "Tên điện thoại:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(45, 226);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 0;
            label4.Text = "RAM:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 258);
            label3.Name = "label3";
            label3.Size = new Size(80, 15);
            label3.TabIndex = 0;
            label3.Text = "Bộ nhớ trong:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 83);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 0;
            label1.Text = "Màn hình:";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(dataGridView_TSSanPham);
            groupBox1.Location = new Point(335, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(351, 377);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // dataGridView_TSSanPham
            // 
            dataGridView_TSSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_TSSanPham.Location = new Point(16, 22);
            dataGridView_TSSanPham.Name = "dataGridView_TSSanPham";
            dataGridView_TSSanPham.RowTemplate.Height = 25;
            dataGridView_TSSanPham.Size = new Size(317, 342);
            dataGridView_TSSanPham.TabIndex = 0;
            dataGridView_TSSanPham.CellContentClick += dataGridView_TTSanPham_CellContentClick;
            // 
            // ThongSoKyThuat
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = QuanLyDienThoaiFPT.Properties.Resources.pure_white_background_85a2a7fd;
            ClientSize = new Size(706, 389);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "ThongSoKyThuat";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Thông số kỹ thuật";
            Load += ThongSoKyThuat_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView_TSSanPham).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox2;
        private ComboBox combobox_BoNhoTrong;
        private ComboBox combobox_RAM;
        private TextBox textBox_MaSP;
        private Label label7;
        private TextBox textbox_ManHinh;
        private TextBox textbox_TenDienThoai;
        private Label label6;
        private Label label4;
        private Label label3;
        private Label label1;
        private GroupBox groupBox1;
        private DataGridView dataGridView_TSSanPham;
        private TextBox textbox_Sac;
        private Label label11;
        private TextBox textbox_DungLuongPin;
        private Label label2;
        private TextBox textbox_CPU;
        private Label label10;
        private TextBox textbox_CameraTruoc;
        private Label label9;
        private TextBox textbox_CameraSau;
        private Label label8;
        private TextBox textbox_HeDieuHanh;
        private Label label5;
        private Button button_Khoitao;
        private Button button_Sua;
        private ImageList imageList1;
    }
}