﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_DangNhap_Dangky_QMK
{
    public partial class QuanLyAdmin : Form
    {
        SqlCommand command;
        SqlConnection sqlConnection = Connection.GetSqlConnection();
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        private void loaddata()
        {
            command = sqlConnection.CreateCommand();
            command.CommandText = "Select * from Admin";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_Admin.DataSource = table;
        }
        public QuanLyAdmin()
        {
            InitializeComponent();
        }

        private void dataGridView_Admin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView_Admin.CurrentRow.Index;
            textBox_MaAdmin.Text = dataGridView_Admin.Rows[i].Cells[0].Value.ToString();
            textBox_HoTenAdmin.Text = dataGridView_Admin.Rows[i].Cells[1].Value.ToString();
            textbox_DiaChiAdmin.Text = dataGridView_Admin.Rows[i].Cells[2].Value.ToString();
            textbox_DienThoaiAdmin.Text = dataGridView_Admin.Rows[i].Cells[3].Value.ToString();
            textbox_TenDangNhap.Text = dataGridView_Admin.Rows[i].Cells[4].Value.ToString();
            textbox_MatKhau.Text = dataGridView_Admin.Rows[i].Cells[5].Value.ToString();
            dateTimePicker_NgaySinh.Text = dataGridView_Admin.Rows[i].Cells[6].Value.ToString();
            comboBox_GioiTinh.Text = dataGridView_Admin.Rows[i].Cells[7].Value.ToString();
            textBox_EmailAdmin.Text = dataGridView_Admin.Rows[i].Cells[8].Value.ToString();
            comboBox_QuyenAdmin.Text = dataGridView_Admin.Rows[i].Cells[9].Value.ToString();
        }
        private void LoadComboBox()
        {
            comboBox_GioiTinh.Items.Clear();
            List<PhanLoai> phanLoais = new List<PhanLoai>()
            {
                new PhanLoai() { Loai = "True", GioiTinh = "Nam" },
                new PhanLoai() { Loai = "False", GioiTinh = "Nữ" },
            };
            comboBox_GioiTinh.DataSource = phanLoais;
            comboBox_GioiTinh.DisplayMember = "GioiTinh";
            comboBox_GioiTinh.ValueMember = "Loai";
        }
        private void QuanLyAdmin_Load(object sender, EventArgs e)
        {
            LoadComboBox();
            sqlConnection.Open();
            loaddata();
        }

        private void button_Them_Click(object sender, EventArgs e)
        {
            string gioitinh = comboBox_GioiTinh.SelectedValue.ToString();
            if (textBox_HoTenAdmin.Text == "" || textbox_DiaChiAdmin.Text == "" || textbox_DienThoaiAdmin.Text == "" || textbox_TenDangNhap.Text == "" || textbox_MatKhau.Text == "" || dateTimePicker_NgaySinh.Text == "" || comboBox_GioiTinh.Text == "" || textBox_EmailAdmin.Text == "" || comboBox_QuyenAdmin.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "insert into ADMIN(HoTenAdmin, DiaChiAdmin, DienThoaiAdmin, TenDNAdmin, MatKhauAdmin, NgaySinhAdmin, GioiTinhAdmin, EmailAdmin, QuyenAdmin) values('" + textBox_HoTenAdmin.Text + "','" + textbox_DiaChiAdmin.Text + "','" + textbox_DienThoaiAdmin.Text + "','" + textbox_TenDangNhap.Text + "','" + textbox_MatKhau.Text + "','" + dateTimePicker_NgaySinh.Text + "','" + gioitinh + "','" + textBox_EmailAdmin.Text + "','" + comboBox_QuyenAdmin.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã thêm dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            string gioitinh = comboBox_GioiTinh.SelectedValue.ToString();
            if (textBox_HoTenAdmin.Text == "" || textbox_DiaChiAdmin.Text == "" || textbox_DienThoaiAdmin.Text == "" || textbox_TenDangNhap.Text == "" || textbox_MatKhau.Text == "" || dateTimePicker_NgaySinh.Text == "" || comboBox_GioiTinh.Text == "" || textBox_EmailAdmin.Text == "" || comboBox_QuyenAdmin.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "update ADMIN set HoTenAdmin = '" + textBox_HoTenAdmin.Text + "', DiaChiAdmin = '" + textbox_DiaChiAdmin.Text + "', DienThoaiAdmin= '" + textbox_DienThoaiAdmin.Text + "', TenDNAdmin = '" + textbox_TenDangNhap.Text + "', MatKhauAdmin = '" + textbox_MatKhau.Text + "', NgaySinhAdmin = '" + dateTimePicker_NgaySinh.Text + "', GioiTinhAdmin = '" + gioitinh + "', EmailAdmin = '" + textBox_EmailAdmin.Text + "', QuyenAdmin = '" + comboBox_QuyenAdmin.Text + "'  where MaAdmin = '" + textBox_MaAdmin.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã sữa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            if (textBox_HoTenAdmin.Text == "" || textbox_DiaChiAdmin.Text == "" || textbox_DienThoaiAdmin.Text == "" || textbox_TenDangNhap.Text == "" || textbox_MatKhau.Text == "" || dateTimePicker_NgaySinh.Text == "" || comboBox_GioiTinh.Text == "" || textBox_EmailAdmin.Text == "" || comboBox_QuyenAdmin.Text == "")
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            command = sqlConnection.CreateCommand();
            command.CommandText = "delete from ADMIN where MaAdmin= '" + textBox_MaAdmin.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
            MessageBox.Show("Đã xóa dữ liệu được chọn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button_Khoitao_Click(object sender, EventArgs e)
        {
            textBox_MaAdmin.Clear();
            textBox_HoTenAdmin.Clear();
            textbox_DiaChiAdmin.Clear();
            textbox_DienThoaiAdmin.Clear();
            textBox_EmailAdmin.Clear();
            textbox_MatKhau.Clear();
            textbox_TenDangNhap.Clear();
            comboBox_GioiTinh.ResetText();
            dateTimePicker_NgaySinh.ResetText();
            comboBox_QuyenAdmin.ResetText();
        }
    }
}
