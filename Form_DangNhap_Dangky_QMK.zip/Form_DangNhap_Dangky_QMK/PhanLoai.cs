﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Form_DangNhap_Dangky_QMK
{
    internal class PhanLoai
    { 
        public string MaLSP { get; set; }
        public string TenLSP { get; set; }
        public string MaTT { get; set; }
        public string TenTinhTrang { get; set; }
        public string Loai { get; set; }
        public string GioiTinh { get; set; }
        public string LoaiTT { get; set; }
        public string TinhTrangTT { get; set; }
        public string LoaiGH { get; set; }
        public string TinhTrangGH { get; set; }
    }
}
